import os
import asyncio
from io import BytesIO

from dotenv import load_dotenv
from aiogram import Bot, Dispatcher, Router, F
from aiogram.types import (
    Message, ReplyKeyboardMarkup, KeyboardButton,
    ReplyKeyboardRemove, BufferedInputFile
)
from aiogram.filters import CommandStart
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import StatesGroup, State
from aiogram.fsm.storage.memory import MemoryStorage

# REPORTLAB + Montserrat
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Image
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import cm
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle

load_dotenv()
BOT_TOKEN = os.getenv("BOT_TOKEN")

bot = Bot(token=BOT_TOKEN)
dp = Dispatcher(storage=MemoryStorage())
router = Router()

# Регистрируем шрифт Montserrat (должен лежать в папке fonts/Montserrat-Regular.ttf)
pdfmetrics.registerFont(TTFont('Montserrat', 'fonts/Montserrat-Regular.ttf'))

# Создаём папку для фото, если её нет
os.makedirs("photos", exist_ok=True)

# ---------------------------
# Клавиатуры
# ---------------------------

# Главное меню языка
choose_language_kb = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="Создать анкету на русском")],
        [KeyboardButton(text="Create form in English")],
    ],
    resize_keyboard=True
)

# Кнопка "Назад" (и "Back") вместе
back_to_lang_kb = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="Назад"), KeyboardButton(text="Back")]
    ],
    resize_keyboard=True
)

# "Добавить / Завершить" (рус)
add_or_finish_kb_ru = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="Добавить данные")],
        [KeyboardButton(text="Завершить создание документа")],
    ],
    resize_keyboard=True
)
# "Add / Finish" (англ)
add_or_finish_kb_en = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="Add data")],
        [KeyboardButton(text="Finish document")],
    ],
    resize_keyboard=True
)

# "Добавить опыт работы" / "Перейти к следующему шагу" (рус)
work_or_next_kb_ru = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="Добавить опыт работы")],
        [KeyboardButton(text="Перейти к следующему шагу")],
    ],
    resize_keyboard=True
)
# (англ)
work_or_next_kb_en = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="Add work experience")],
        [KeyboardButton(text="Go to next step")],
    ],
    resize_keyboard=True
)

# Военная служба (рус)
service_or_next_kb_ru = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="Добавить опыт службы")],
        [KeyboardButton(text="Перейти к следующему шагу")],
    ],
    resize_keyboard=True
)
# (англ)
service_or_next_kb_en = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="Add military service")],
        [KeyboardButton(text="Go to next step")],
    ],
    resize_keyboard=True
)

# Образование (рус)
edu_or_next_kb_ru = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="Добавить образование")],
        [KeyboardButton(text="Перейти к следующему шагу")],
    ],
    resize_keyboard=True
)
# (англ)
edu_or_next_kb_en = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="Add education")],
        [KeyboardButton(text="Go to next step")],
    ],
    resize_keyboard=True
)

# "Добавить блок доп. инф." / "Завершить" (рус)
finish_or_add_block_kb_ru = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="Добавить блок доп. информации")],
        [KeyboardButton(text="Завершить")],
    ],
    resize_keyboard=True
)
# (англ)
finish_or_add_block_kb_en = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="Add extra info block")],
        [KeyboardButton(text="Finish")],
    ],
    resize_keyboard=True
)

# После генерации: "Внести исправления" / "Завершить" (рус)
after_generation_kb_ru = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="Внести исправления")],
        [KeyboardButton(text="Завершить")],
    ],
    resize_keyboard=True
)
# (англ)
after_generation_kb_en = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="Edit data")],
        [KeyboardButton(text="Finish")],
    ],
    resize_keyboard=True
)

# Меню "Внести исправления" (рус)
edit_menu_kb_ru = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="Фотография 3x4"), KeyboardButton(text="Фотография в полный рост")],
        [KeyboardButton(text="Общая информация"), KeyboardButton(text="Опыт работы")],
        [KeyboardButton(text="Военная служба"), KeyboardButton(text="Образование")],
        [KeyboardButton(text="Дополнительная информация")],
    ],
    resize_keyboard=True
)
# (англ)
edit_menu_kb_en = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="Photo 3x4"), KeyboardButton(text="Full height photo")],
        [KeyboardButton(text="Basic info"), KeyboardButton(text="Work experience")],
        [KeyboardButton(text="Military service"), KeyboardButton(text="Education")],
        [KeyboardButton(text="Additional info")],
    ],
    resize_keyboard=True
)

# ---------------------------
# Состояния
# ---------------------------
class FormStates(StatesGroup):
    CHOOSE_LANG = State()
    WAITING_PHOTO_34 = State()
    WAITING_PHOTO_FULL = State()
    WAITING_ADD_OR_FINISH = State()

    WAITING_BASIC_INFO = State()
    WAITING_WORK = State()
    WAITING_WORK_CHOICE = State()

    WAITING_MILITARY_DATA = State()
    WAITING_MILITARY_CHOICE = State()

    WAITING_EDUCATION_DATA = State()
    WAITING_EDUCATION_CHOICE = State()

    WAITING_ADDITIONAL_DATA = State()
    WAITING_FINISH_OR_ADD_BLOCK = State()

    PDF_GENERATED = State()
    WAITING_EDIT = State()

# ---------------------------
# Получение языка
# ---------------------------
async def get_lang(state: FSMContext) -> str:
    data = await state.get_data()
    return data.get("lang", "ru")

# ---------------------------
# Команда /start
# ---------------------------
@router.message(CommandStart())
async def cmd_start(message: Message, state: FSMContext):
    """
    Начало: выбор языка (рус/англ). Очищаем состояние.
    """
    await state.clear()
    await message.answer(
        "Привет! Это бот для создания анкет.\nВыберите язык анкеты:",
        reply_markup=choose_language_kb
    )
    await state.set_state(FormStates.CHOOSE_LANG)

# ---------------------------
# Обработка выбора языка
# ---------------------------
@router.message(FormStates.CHOOSE_LANG, F.text == "Создать анкету на русском")
async def form_russian(message: Message, state: FSMContext):
    await state.update_data({
        "lang": "ru",
        "photo_3x4": None,
        "photo_full": None,
        "basic_info": {},
        "work_experience": [],
        "military_service": None,
        "education": [],
        "additional_info": None
    })
    await message.answer(
        "Вы выбрали анкету на русском.\n"
        "Пожалуйста, отправьте фотографию (как на паспорт) — 3×4.",
        reply_markup=back_to_lang_kb
    )
    await state.set_state(FormStates.WAITING_PHOTO_34)


@router.message(FormStates.CHOOSE_LANG, F.text == "Create form in English")
async def form_english(message: Message, state: FSMContext):
    await state.update_data({
        "lang": "en",
        "photo_3x4": None,
        "photo_full": None,
        "basic_info": {},
        "work_experience": [],
        "military_service": None,
        "education": [],
        "additional_info": None
    })
    await message.answer(
        "You have chosen to fill the form in English.\n"
        "Please send a 3×4 photo (like on a passport).",
        reply_markup=back_to_lang_kb
    )
    await state.set_state(FormStates.WAITING_PHOTO_34)

@router.message(FormStates.CHOOSE_LANG, F.text.in_(["Назад", "Back"]))
async def choose_lang_back(message: Message, state: FSMContext):
    await cmd_start(message, state)

# ---------------------------
# Получение фото 3×4
# ---------------------------
@router.message(FormStates.WAITING_PHOTO_34, F.text.in_(["Назад", "Back"]))
async def photo34_back(message: Message, state: FSMContext):
    await cmd_start(message, state)

@router.message(FormStates.WAITING_PHOTO_34, F.photo)
async def receive_photo_34(message: Message, state: FSMContext):
    file_id = message.photo[-1].file_id
    await state.update_data({"photo_3x4": file_id})
    lang = await get_lang(state)

    if lang == "ru":
        text_msg = (
            "Фото 3×4 получено!\n"
            "Теперь отправьте фотографию в полный рост."
        )
    else:
        text_msg = (
            "3×4 photo received!\n"
            "Now send a full-height photo."
        )

    await message.answer(text_msg, reply_markup=back_to_lang_kb)
    await state.set_state(FormStates.WAITING_PHOTO_FULL)

# ---------------------------
# Получение фото в полный рост
# ---------------------------
@router.message(FormStates.WAITING_PHOTO_FULL, F.text.in_(["Назад", "Back"]))
async def photo_full_back(message: Message, state: FSMContext):
    """
    Вернуться к фото 3×4.
    """
    lang = await get_lang(state)
    if lang == "ru":
        await form_russian(message, state)
    else:
        await form_english(message, state)

@router.message(FormStates.WAITING_PHOTO_FULL, F.photo)
async def receive_photo_full(message: Message, state: FSMContext):
    file_id = message.photo[-1].file_id
    await state.update_data({"photo_full": file_id})

    data = await state.get_data()
    lang = data.get("lang", "ru")

    if lang == "ru":
        text_msg = (
            "Фото в полный рост получено.\n"
            "Теперь вы можете добавить информацию или сразу завершить документ."
        )
        kb = add_or_finish_kb_ru
    else:
        text_msg = (
            "Full-height photo received.\n"
            "Now you can add more data or finish the document."
        )
        kb = add_or_finish_kb_en

    await message.answer(text_msg, reply_markup=kb)
    await state.set_state(FormStates.WAITING_ADD_OR_FINISH)

# ---------------------------
# "Добавить данные" или "Завершить документ"
# ---------------------------
@router.message(FormStates.WAITING_ADD_OR_FINISH)
async def add_or_finish(message: Message, state: FSMContext):
    txt = message.text
    lang = await get_lang(state)

    if lang == "ru":
        if txt == "Добавить данные":
            await add_data_start_ru(message, state)
        elif txt == "Завершить создание документа":
            await generate_and_send_pdf(message, state)
            await state.set_state(FormStates.PDF_GENERATED)
        else:
            await message.answer(
                "Пожалуйста, используйте кнопки: «Добавить данные» или «Завершить создание документа»."
            )
    else:
        if txt == "Add data":
            await add_data_start_en(message, state)
        elif txt == "Finish document":
            await generate_and_send_pdf(message, state)
            await state.set_state(FormStates.PDF_GENERATED)
        else:
            await message.answer(
                "Please use the buttons: 'Add data' or 'Finish document'."
            )


# ---------------------------
# Добавление основной инфы (рус)
# ---------------------------
async def add_data_start_ru(message: Message, state: FSMContext):
    await message.answer(
        "Пожалуйста, укажите дату и место рождения, место регистрации, рост, вес, семейное положение.\n\n"
        "Пример (каждое поле с новой строки!):\n"
        "01.01.1990\n"
        "Санкт-Петербург\n"
        "Москва (текущее место проживания)\n"
        "190\n"
        "90\n"
        "Женат\n\n"
        "Или нажмите «Пропустить».",
        reply_markup=ReplyKeyboardMarkup(
            keyboard=[
                [KeyboardButton(text="Пропустить")],
            ],
            resize_keyboard=True
        )
    )
    await state.set_state(FormStates.WAITING_BASIC_INFO)

# ---------------------------
# Добавление основной инфы (англ)
# ---------------------------
async def add_data_start_en(message: Message, state: FSMContext):
    await message.answer(
        "Please enter birth date, place of birth, registration place, height, weight, marital status.\n"
        "Example (one field per line!):\n"
        "01/01/1990\n"
        "London\n"
        "New York (current residence)\n"
        "180\n"
        "75\n"
        "Married\n\n"
        "Or press 'Skip'.",
        reply_markup=ReplyKeyboardMarkup(
            keyboard=[
                [KeyboardButton(text="Skip")],
            ],
            resize_keyboard=True
        )
    )
    await state.set_state(FormStates.WAITING_BASIC_INFO)

# ---------------------------
# Обработка основной инфы (рус/англ)
# ---------------------------
@router.message(FormStates.WAITING_BASIC_INFO)
async def receive_basic_info(message: Message, state: FSMContext):
    txt = message.text
    lang = await get_lang(state)

    # Проверка на "Пропустить" / "Skip"
    if lang == "ru" and txt == "Пропустить":
        await state.update_data({"basic_info": {
            "birth_date": "Пропущено",
            "registration": "Пропущено",
            "residence": "Пропущено",
            "height": "Пропущено",
            "weight": "Пропущено",
            "marital": "Пропущено"
        }})
        await ask_for_work(message, state)
        return
    elif lang == "en" and txt == "Skip":
        await state.update_data({"basic_info": {
            "birth_date": "Skipped",
            "registration": "Skipped",
            "residence": "Skipped",
            "height": "Skipped",
            "weight": "Skipped",
            "marital": "Skipped"
        }})
        await ask_for_work(message, state)
        return

    lines = message.text.split("\n")

    if len(lines) < 6 and lang == "ru":
        await message.answer("Нужно 6 строк!")
        return
    elif len(lines) < 6 and lang == "en":
        await message.answer("Need 6 lines!")
        return

    bdict = {
        "birth_date": lines[0].strip(),
        "registration": lines[1].strip(),
        "residence": lines[2].strip(),
        "height": lines[3].strip(),
        "weight": lines[4].strip(),
        "marital": lines[5].strip()
    }
    await state.update_data({"basic_info": bdict})
    await ask_for_work(message, state)

# ---------------------------
# Запрос данных об опыте работы (рус/англ)
# ---------------------------
async def ask_for_work(message: Message, state: FSMContext):
    lang = await get_lang(state)

    if lang == "ru":
        prompt = (
            "Пожалуйста, укажите данные об опыте работы (5 строк):\n"
            "1) Наименование работодателя\n"
            "2) Город места работы\n"
            "3) Период (например: 2010 2015)\n"
            "4) Должность\n"
            "5) Обязанности\n\n"
            "Или нажмите «Пропустить»."
        )
        kb = ReplyKeyboardMarkup(
            keyboard=[
                [KeyboardButton(text="Пропустить")],
            ],
            resize_keyboard=True
        )
    else:
        prompt = (
            "Please enter work experience (5 lines):\n"
            "1) Employer\n"
            "2) City\n"
            "3) Period (e.g. 2010 2015)\n"
            "4) Position\n"
            "5) Duties\n\n"
            "Or press 'Skip'."
        )
        kb = ReplyKeyboardMarkup(
            keyboard=[
                [KeyboardButton(text="Skip")],
            ],
            resize_keyboard=True
        )

    await message.answer(prompt, reply_markup=kb)
    await state.set_state(FormStates.WAITING_WORK)

@router.message(FormStates.WAITING_WORK)
async def receive_work(message: Message, state: FSMContext):
    txt = message.text
    lang = await get_lang(state)

    # Пропустить
    if lang == "ru" and txt == "Пропустить":
        await go_next_work(message, state)
        return
    elif lang == "en" and txt == "Skip":
        await go_next_work(message, state)
        return

    lines = txt.split("\n")
    if len(lines) < 5 and lang == "ru":
        await message.answer("Нужно 5 строк!")
        return
    elif len(lines) < 5 and lang == "en":
        await message.answer("Need 5 lines!")
        return

    data_ = await state.get_data()
    wlist = data_.get("work_experience", [])
    wdict = {
        "employer": lines[0].strip(),
        "city": lines[1].strip(),
        "period": lines[2].strip(),
        "position": lines[3].strip(),
        "duties": lines[4].strip()
    }
    wlist.append(wdict)
    await state.update_data({"work_experience": wlist})

    # Предложить "Добавить опыт" или "Следующий шаг"
    if lang == "ru":
        text_ = "Опыт работы добавлен. «Добавить опыт работы» или «Перейти к следующему шагу»?"
        kb = work_or_next_kb_ru
    else:
        text_ = "Work experience added. 'Add work experience' or 'Go to next step'?"
        kb = work_or_next_kb_en

    await message.answer(text_, reply_markup=kb)
    await state.set_state(FormStates.WAITING_WORK_CHOICE)

@router.message(FormStates.WAITING_WORK_CHOICE)
async def work_choice(message: Message, state: FSMContext):
    txt = message.text
    lang = await get_lang(state)

    # Русский
    if lang == "ru":
        if txt == "Добавить опыт работы":
            await message.answer(
                "Введите ещё 5 строк или «Пропустить»",
                reply_markup=ReplyKeyboardMarkup(
                    keyboard=[
                        [KeyboardButton(text="Пропустить")],
                    ],
                    resize_keyboard=True
                )
            )
            await state.set_state(FormStates.WAITING_WORK)
        elif txt == "Перейти к следующему шагу":
            await ask_military(message, state)
        else:
            await message.answer("Пожалуйста, выберите «Добавить опыт работы» или «Перейти к следующему шагу».")
    else:
        # Английский
        if txt == "Add work experience":
            await message.answer(
                "Enter another 5 lines or 'Skip'.",
                reply_markup=ReplyKeyboardMarkup(
                    keyboard=[
                        [KeyboardButton(text="Skip")],
                    ],
                    resize_keyboard=True
                )
            )
            await state.set_state(FormStates.WAITING_WORK)
        elif txt == "Go to next step":
            await ask_military(message, state)
        else:
            await message.answer("Please choose 'Add work experience' or 'Go to next step'.")

# ---------------------------
# Военная служба (рус/англ)
# ---------------------------
async def ask_military(message: Message, state: FSMContext):
    lang = await get_lang(state)

    if lang == "ru":
        txt = (
            "Пожалуйста, укажите данные о военной службе (4 строки) или «Пропустить».\n"
            "1) Наименование подразделения\n"
            "2) Период (e.g. 2010 2012)\n"
            "3) Звание\n"
            "4) Обязанности/Примечания\n"
        )
        kb = ReplyKeyboardMarkup(
            keyboard=[
                [KeyboardButton(text="Пропустить")],
            ],
            resize_keyboard=True
        )
    else:
        txt = (
            "Please provide military service data (4 lines) or 'Skip'.\n"
            "1) Subdivision\n"
            "2) Period (e.g. 2010 2012)\n"
            "3) Rank\n"
            "4) Duties/Notes\n"
        )
        kb = ReplyKeyboardMarkup(
            keyboard=[
                [KeyboardButton(text="Skip")],
            ],
            resize_keyboard=True
        )

    await message.answer(txt, reply_markup=kb)
    await state.set_state(FormStates.WAITING_MILITARY_DATA)

@router.message(FormStates.WAITING_MILITARY_DATA)
async def receive_military(message: Message, state: FSMContext):
    txt = message.text
    lang = await get_lang(state)

    if lang == "ru" and txt == "Пропустить":
        await state.update_data({"military_service": None})
        await ask_for_education(message, state)
        return
    elif lang == "en" and txt == "Skip":
        await state.update_data({"military_service": None})
        await ask_for_education(message, state)
        return

    lines = txt.split("\n")
    if len(lines) < 4 and lang == "ru":
        await message.answer("Нужно 4 строки!")
        return
    elif len(lines) < 4 and lang == "en":
        await message.answer("Need 4 lines!")
        return

    ms_dict = {
        "subdivision": lines[0].strip(),
        "period": lines[1].strip(),
        "rank": lines[2].strip(),
        "notes": lines[3].strip()
    }
    await state.update_data({"military_service": ms_dict})

    if lang == "ru":
        txt_ = "Военная служба добавлена. «Добавить опыт службы» или «Перейти к следующему шагу»?"
        kb = service_or_next_kb_ru
    else:
        txt_ = "Military service added. 'Add military service' or 'Go to next step'?"
        kb = service_or_next_kb_en

    await message.answer(txt_, reply_markup=kb)
    await state.set_state(FormStates.WAITING_MILITARY_CHOICE)

@router.message(FormStates.WAITING_MILITARY_CHOICE)
async def military_choice(message: Message, state: FSMContext):
    txt = message.text
    lang = await get_lang(state)

    if lang == "ru":
        if txt == "Добавить опыт службы":
            await message.answer(
                "Введите ещё 4 строки или «Пропустить»",
                reply_markup=ReplyKeyboardMarkup(
                    keyboard=[
                        [KeyboardButton(text="Пропустить")],
                    ],
                    resize_keyboard=True
                )
            )
            await state.set_state(FormStates.WAITING_MILITARY_DATA)
        elif txt == "Перейти к следующему шагу":
            await ask_for_education(message, state)
        else:
            await message.answer("Кнопки: «Добавить опыт службы» или «Перейти к следующему шагу».")
    else:
        if txt == "Add military service":
            await message.answer(
                "Enter another 4 lines or 'Skip'.",
                reply_markup=ReplyKeyboardMarkup(
                    keyboard=[
                        [KeyboardButton(text="Skip")],
                    ],
                    resize_keyboard=True
                )
            )
            await state.set_state(FormStates.WAITING_MILITARY_DATA)
        elif txt == "Go to next step":
            await ask_for_education(message, state)
        else:
            await message.answer("Buttons: 'Add military service' or 'Go to next step'.")

# ---------------------------
# Образование (рус/англ)
# ---------------------------
async def ask_for_education(message: Message, state: FSMContext):
    lang = await get_lang(state)

    if lang == "ru":
        txt = (
            "Пожалуйста, укажите данные об образовании (4 строки) или «Пропустить».\n"
            "1) Наименование учебного учреждения\n"
            "2) Период (e.g. 2010 2015)\n"
            "3) Вид образования (высшее/среднее/…)\n"
            "4) Специальность\n"
        )
        kb = ReplyKeyboardMarkup(
            keyboard=[
                [KeyboardButton(text="Пропустить")],
            ],
            resize_keyboard=True
        )
    else:
        txt = (
            "Please provide education data (4 lines) or 'Skip'.\n"
            "1) Institution name\n"
            "2) Period (e.g. 2010 2015)\n"
            "3) Education type (college, high school, etc.)\n"
            "4) Specialty\n"
        )
        kb = ReplyKeyboardMarkup(
            keyboard=[
                [KeyboardButton(text="Skip")],
            ],
            resize_keyboard=True
        )

    await message.answer(txt, reply_markup=kb)
    await state.set_state(FormStates.WAITING_EDUCATION_DATA)

@router.message(FormStates.WAITING_EDUCATION_DATA)
async def receive_education(message: Message, state: FSMContext):
    txt = message.text
    lang = await get_lang(state)

    if lang == "ru" and txt == "Пропустить":
        await go_next_education(message, state)
        return
    elif lang == "en" and txt == "Skip":
        await go_next_education(message, state)
        return

    lines = txt.split("\n")
    if len(lines) < 4 and lang == "ru":
        await message.answer("Нужно 4 строки!")
        return
    elif len(lines) < 4 and lang == "en":
        await message.answer("Need 4 lines!")
        return

    data_ = await state.get_data()
    edu_list = data_.get("education", [])
    e_dict = {
        "institution": lines[0].strip(),
        "period": lines[1].strip(),
        "type": lines[2].strip(),
        "specialty": lines[3].strip()
    }
    edu_list.append(e_dict)
    await state.update_data({"education": edu_list})

    if lang == "ru":
        txt_ = "Образование добавлено. «Добавить образование» или «Перейти к следующему шагу»?"
        kb = edu_or_next_kb_ru
    else:
        txt_ = "Education added. 'Add education' or 'Go to next step'?"
        kb = edu_or_next_kb_en

    await message.answer(txt_, reply_markup=kb)
    await state.set_state(FormStates.WAITING_EDUCATION_CHOICE)

@router.message(FormStates.WAITING_EDUCATION_CHOICE)
async def education_choice(message: Message, state: FSMContext):
    txt = message.text
    lang = await get_lang(state)

    if lang == "ru":
        if txt == "Добавить образование":
            await message.answer(
                "Введите ещё 4 строки или «Пропустить».",
                reply_markup=ReplyKeyboardMarkup(
                    keyboard=[
                        [KeyboardButton(text="Пропустить")],
                    ],
                    resize_keyboard=True
                )
            )
            await state.set_state(FormStates.WAITING_EDUCATION_DATA)
        elif txt == "Перейти к следующему шагу":
            await ask_for_additional(message, state)
        else:
            await message.answer("Кнопки: «Добавить образование» или «Перейти к следующему шагу».")
    else:
        if txt == "Add education":
            await message.answer(
                "Enter another 4 lines or 'Skip'.",
                reply_markup=ReplyKeyboardMarkup(
                    keyboard=[
                        [KeyboardButton(text="Skip")],
                    ],
                    resize_keyboard=True
                )
            )
            await state.set_state(FormStates.WAITING_EDUCATION_DATA)
        elif txt == "Go to next step":
            await ask_for_additional(message, state)
        else:
            await message.answer("Buttons: 'Add education' or 'Go to next step'.")

# ---------------------------
# Дополнительные данные
# ---------------------------
async def ask_for_additional(message: Message, state: FSMContext):
    lang = await get_lang(state)

    if lang == "ru":
        txt_ = "Дополнительные данные (навыки, характеристики) или «Пропустить»."
        kb_ = ReplyKeyboardMarkup(
            keyboard=[
                [KeyboardButton(text="Пропустить")],
            ],
            resize_keyboard=True
        )
    else:
        txt_ = "Additional info (skills, etc.) or 'Skip'."
        kb_ = ReplyKeyboardMarkup(
            keyboard=[
                [KeyboardButton(text="Skip")],
            ],
            resize_keyboard=True
        )

    await message.answer(txt_, reply_markup=kb_)
    await state.set_state(FormStates.WAITING_ADDITIONAL_DATA)

@router.message(FormStates.WAITING_ADDITIONAL_DATA)
async def receive_additional(message: Message, state: FSMContext):
    txt = message.text
    lang = await get_lang(state)

    if lang == "ru" and txt == "Пропустить":
        await state.update_data({"additional_info": "Пропущено"})
        await finish_or_add_block_ru(message, state)
        return
    elif lang == "en" and txt == "Skip":
        await state.update_data({"additional_info": "Skipped"})
        await finish_or_add_block_en(message, state)
        return

    await state.update_data({"additional_info": txt})

    if lang == "ru":
        await finish_or_add_block_ru(message, state)
    else:
        await finish_or_add_block_en(message, state)

async def finish_or_add_block_ru(message: Message, state: FSMContext):
    await message.answer(
        "Можете «Завершить» (создать PDF) или «Добавить блок доп. информации».",
        reply_markup=finish_or_add_block_kb_ru
    )
    await state.set_state(FormStates.WAITING_FINISH_OR_ADD_BLOCK)

async def finish_or_add_block_en(message: Message, state: FSMContext):
    await message.answer(
        "You can 'Finish' (create PDF) or 'Add extra info block'.",
        reply_markup=finish_or_add_block_kb_en
    )
    await state.set_state(FormStates.WAITING_FINISH_OR_ADD_BLOCK)

@router.message(FormStates.WAITING_FINISH_OR_ADD_BLOCK)
async def finish_or_add_block(message: Message, state: FSMContext):
    txt = message.text
    lang = await get_lang(state)

    if lang == "ru":
        if txt == "Завершить":
            await generate_and_send_pdf(message, state)
            await state.set_state(FormStates.PDF_GENERATED)
        elif txt == "Добавить блок доп. информации":
            await message.answer("Добавьте новый блок информации или вернитесь к предыдущим шагам.")
        else:
            await message.answer("Кнопки: «Завершить» или «Добавить блок доп. информации».")
    else:
        if txt == "Finish":
            await generate_and_send_pdf(message, state)
            await state.set_state(FormStates.PDF_GENERATED)
        elif txt == "Add extra info block":
            await message.answer("Add a new extra info block or go back to previous steps.")
        else:
            await message.answer("Buttons: 'Finish' or 'Add extra info block'.")

# ---------------------------
# Генерация и отправка PDF
# ---------------------------
async def generate_and_send_pdf(message: Message, state: FSMContext):
    """
    1) Скачивает фото 3x4 и фото в полный рост на диск (если есть).
    2) Вызывает generate_pdf(...) для формирования PDF (возвращает BytesIO).
    3) Отправляет PDF пользователю.
    """
    data = await state.get_data()

    # Скачиваем и локально сохраняем фото 3x4
    photo_3x4_id = data.get("photo_3x4")
    if photo_3x4_id:
        photo_3x4_local_path = f"photos/3x4_{photo_3x4_id}.jpg"
        file_info = await bot.get_file(photo_3x4_id)
        await bot.download_file(file_info.file_path, photo_3x4_local_path)
        data["photo_3x4"] = photo_3x4_local_path
    else:
        data["photo_3x4"] = None

    # Скачиваем и локально сохраняем фото в полный рост
    photo_full_id = data.get("photo_full")
    if photo_full_id:
        photo_full_local_path = f"photos/full_{photo_full_id}.jpg"
        file_info = await bot.get_file(photo_full_id)
        await bot.download_file(file_info.file_path, photo_full_local_path)
        data["photo_full"] = photo_full_local_path
    else:
        data["photo_full"] = None

    pdf_buffer = await generate_pdf(data)
    pdf_buffer.seek(0)

    pdf_file = BufferedInputFile(
        file=pdf_buffer.read(),
        filename="Form.pdf"
    )
    await message.answer_document(pdf_file)

# ---------------------------
# Функция генерации PDF
# ---------------------------
async def generate_pdf(data: dict) -> BytesIO:
    """
    Сюда можно дописать подробный вывод (basic_info, work_experience и т.д.)
    Для примера делаем только заголовок и фото.
    """
    buffer = BytesIO()
    doc = SimpleDocTemplate(
        buffer, pagesize=A4,
        leftMargin=2 * cm, rightMargin=2 * cm,
        topMargin=2 * cm, bottomMargin=2 * cm
    )

    styles = getSampleStyleSheet()
    style_normal = styles['Normal']
    style_normal.fontName = 'Montserrat'
    style_normal.fontSize = 10

    style_title = styles['Title']
    style_title.fontName = 'Montserrat'
    style_title.fontSize = 16

    style_heading = ParagraphStyle(
        'Heading',
        parent=style_normal,
        fontName='Montserrat',
        fontSize=12,
        spaceBefore=10,
        spaceAfter=5
    )

    lang = data.get("lang", "ru")

    elements = []

    # Обработка фото
    photo_3x4_path = data.get("photo_3x4")
    if photo_3x4_path and os.path.isfile(photo_3x4_path):
        photo_3x4_img = Image(photo_3x4_path, width=3 * cm, height=4 * cm)
    else:
        photo_3x4_img = Paragraph("<i>No 3x4 photo</i>", style_normal)

    photo_full_path = data.get("photo_full")
    if photo_full_path and os.path.isfile(photo_full_path):
        photo_full_img = Image(photo_full_path, width=4 * cm, height=6 * cm)
    else:
        photo_full_img = Paragraph("<i>No full-height photo</i>", style_normal)

    if lang == "ru":
        elements.append(Paragraph("<b>Анкета</b>", style_title))
        elements.append(Spacer(1, 0.5 * cm))

        elements.append(Paragraph("Фото 3×4:", style_heading))
        elements.append(photo_3x4_img)
        elements.append(Spacer(1, 0.5 * cm))

        elements.append(Paragraph("Фото в полный рост:", style_heading))
        elements.append(photo_full_img)
        elements.append(Spacer(1, 1 * cm))

        # Выводим базовую инфу (пример)
        binfo = data.get("basic_info", {})
        elements.append(Paragraph("Основная информация:", style_heading))
        text_binfo = f"Дата рождения: {binfo.get('birth_date','')}\n" \
                     f"Место регистрации: {binfo.get('registration','')}\n" \
                     f"Текущее место жительства: {binfo.get('residence','')}\n" \
                     f"Рост: {binfo.get('height','')}\n" \
                     f"Вес: {binfo.get('weight','')}\n" \
                     f"Семейное положение: {binfo.get('marital','')}\n"
        elements.append(Paragraph(text_binfo.replace("\n", "<br/>"), style_normal))
        elements.append(Spacer(1, 0.5 * cm))

        # Опыт работы
        work_list = data.get("work_experience", [])
        if work_list:
            elements.append(Paragraph("Опыт работы:", style_heading))
            for idx, wexp in enumerate(work_list, 1):
                wtxt = f"{idx}. {wexp['employer']}, {wexp['city']}, {wexp['period']}, {wexp['position']}, {wexp['duties']}"
                elements.append(Paragraph(wtxt, style_normal))
                elements.append(Spacer(1, 0.2 * cm))

        # Военная служба
        ms = data.get("military_service")
        if ms:
            elements.append(Paragraph("Военная служба:", style_heading))
            ms_txt = (f"Подразделение: {ms['subdivision']}, "
                      f"Период: {ms['period']}, "
                      f"Звание: {ms['rank']}, "
                      f"Примечания: {ms['notes']}")
            elements.append(Paragraph(ms_txt, style_normal))
            elements.append(Spacer(1, 0.5 * cm))

        # Образование
        edu = data.get("education", [])
        if edu:
            elements.append(Paragraph("Образование:", style_heading))
            for idx, e in enumerate(edu, 1):
                etxt = f"{idx}. {e['institution']}, {e['period']}, {e['type']}, {e['specialty']}"
                elements.append(Paragraph(etxt, style_normal))
                elements.append(Spacer(1, 0.2 * cm))

        # Дополнительная информация
        add_info = data.get("additional_info", "")
        if add_info:
            elements.append(Paragraph("Дополнительная информация:", style_heading))
            elements.append(Paragraph(add_info, style_normal))

    else:
        elements.append(Paragraph("<b>Form</b>", style_title))
        elements.append(Spacer(1, 0.5 * cm))

        elements.append(Paragraph("3×4 photo:", style_heading))
        elements.append(photo_3x4_img)
        elements.append(Spacer(1, 0.5 * cm))

        elements.append(Paragraph("Full-height photo:", style_heading))
        elements.append(photo_full_img)
        elements.append(Spacer(1, 1 * cm))

        # Basic info
        binfo = data.get("basic_info", {})
        elements.append(Paragraph("Basic info:", style_heading))
        text_binfo = (f"Birth date: {binfo.get('birth_date','')}\n"
                      f"Registration: {binfo.get('registration','')}\n"
                      f"Residence: {binfo.get('residence','')}\n"
                      f"Height: {binfo.get('height','')}\n"
                      f"Weight: {binfo.get('weight','')}\n"
                      f"Marital status: {binfo.get('marital','')}\n")
        elements.append(Paragraph(text_binfo.replace("\n", "<br/>"), style_normal))
        elements.append(Spacer(1, 0.5 * cm))

        # Work experience
        work_list = data.get("work_experience", [])
        if work_list:
            elements.append(Paragraph("Work experience:", style_heading))
            for idx, wexp in enumerate(work_list, 1):
                wtxt = (f"{idx}. {wexp['employer']}, {wexp['city']}, "
                        f"{wexp['period']}, {wexp['position']}, {wexp['duties']}")
                elements.append(Paragraph(wtxt, style_normal))
                elements.append(Spacer(1, 0.2 * cm))

        # Military service
        ms = data.get("military_service")
        if ms:
            elements.append(Paragraph("Military service:", style_heading))
            ms_txt = (f"Subdivision: {ms['subdivision']}, "
                      f"Period: {ms['period']}, "
                      f"Rank: {ms['rank']}, "
                      f"Notes: {ms['notes']}")
            elements.append(Paragraph(ms_txt, style_normal))
            elements.append(Spacer(1, 0.5 * cm))

        # Education
        edu = data.get("education", [])
        if edu:
            elements.append(Paragraph("Education:", style_heading))
            for idx, e in enumerate(edu, 1):
                etxt = (f"{idx}. {e['institution']}, {e['period']}, "
                        f"{e['type']}, {e['specialty']}")
                elements.append(Paragraph(etxt, style_normal))
                elements.append(Spacer(1, 0.2 * cm))

        # Additional info
        add_info = data.get("additional_info", "")
        if add_info:
            elements.append(Paragraph("Additional info:", style_heading))
            elements.append(Paragraph(add_info, style_normal))

    doc.build(elements)
    buffer.seek(0)
    return buffer

# ---------------------------
# После генерации PDF
# ---------------------------
@router.message(FormStates.PDF_GENERATED)
async def after_pdf_generated(message: Message, state: FSMContext):
    txt = message.text
    lang = await get_lang(state)

    # RU
    if lang == "ru":
        if txt == "Внести исправления":
            await message.answer("Что хотите исправить?", reply_markup=edit_menu_kb_ru)
            await state.set_state(FormStates.WAITING_EDIT)
        elif txt == "Завершить":
            await message.answer("Документ сформирован окончательно. Завершаем.", reply_markup=ReplyKeyboardRemove())
            await state.clear()
        else:
            await message.answer("«Внести исправления» или «Завершить».")
    else:
        # EN
        if txt == "Edit data":
            await message.answer("What do you want to edit?", reply_markup=edit_menu_kb_en)
            await state.set_state(FormStates.WAITING_EDIT)
        elif txt == "Finish":
            await message.answer("Document is finalized. Done.", reply_markup=ReplyKeyboardRemove())
            await state.clear()
        else:
            await message.answer("'Edit data' or 'Finish'.")

# ---------------------------
# Редактирование
# ---------------------------
@router.message(FormStates.WAITING_EDIT)
async def edit_which_block(message: Message, state: FSMContext):
    txt = message.text
    lang = await get_lang(state)

    # 3x4 photo
    if txt in ["Фотография 3x4", "Photo 3x4"]:
        if lang == "ru":
            t = "Пришлите новое фото 3×4."
        else:
            t = "Please send a new 3×4 photo."
        await message.answer(t, reply_markup=back_to_lang_kb)
        await state.set_state(FormStates.WAITING_PHOTO_34)

    # full height photo
    elif txt in ["Фотография в полный рост", "Full height photo"]:
        if lang == "ru":
            t = "Пришлите новое фото в полный рост."
        else:
            t = "Please send a new full-height photo."
        await message.answer(t, reply_markup=back_to_lang_kb)
        await state.set_state(FormStates.WAITING_PHOTO_FULL)

    # Basic info
    elif txt in ["Общая информация", "Basic info"]:
        if lang == "ru":
            t = "Пожалуйста, укажите дату и место рождения, место регистрации, рост, вес, семейное положение.\nИли «Пропустить»."
        else:
            t = "Please enter birth date, registration place, residence, height, weight, marital status.\nOr 'Skip'."
        await message.answer(t)
        await state.set_state(FormStates.WAITING_BASIC_INFO)

    # Work experience
    elif txt in ["Опыт работы", "Work experience"]:
        if lang == "ru":
            question = (
                "Пожалуйста, укажите данные об опыте работы (5 строк):\n"
                "1) Наименование работодателя\n"
                "2) Город\n"
                "3) Период\n"
                "4) Должность\n"
                "5) Обязанности\n"
                "Или «Пропустить»."
            )
        else:
            question = (
                "Please provide work experience (5 lines):\n"
                "1) Employer\n"
                "2) City\n"
                "3) Period\n"
                "4) Position\n"
                "5) Duties\n"
                "Or 'Skip'."
            )
        await message.answer(question)
        await state.set_state(FormStates.WAITING_WORK)

    # Military service
    elif txt in ["Военная служба", "Military service"]:
        await ask_military(message, state)

    # Education
    elif txt in ["Образование", "Education"]:
        await ask_for_education(message, state)

    # Additional info
    elif txt in ["Дополнительная информация", "Additional info"]:
        if lang == "ru":
            q = "Дополнительные данные (навыки, характеристики) или «Пропустить»."
        else:
            q = "Additional info (skills, etc.) or 'Skip'."
        await message.answer(q)
        await state.set_state(FormStates.WAITING_ADDITIONAL_DATA)

    else:
        if lang == "ru":
            await message.answer("Неизвестный блок. Выберите из списка.")
        else:
            await message.answer("Unknown block. Please choose from the list.")

# ---------------------------
# Запуск бота
# ---------------------------
dp.include_router(router)

async def main():
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())