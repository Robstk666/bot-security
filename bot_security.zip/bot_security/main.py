import os
import asyncio
from datetime import datetime
from io import BytesIO

from dotenv import load_dotenv
from aiogram import Bot, Dispatcher, Router, F
from aiogram.types import (
    Message, PhotoSize, Document,
    ReplyKeyboardMarkup, KeyboardButton,
    ReplyKeyboardRemove, BufferedInputFile
)
from aiogram.filters import CommandStart
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import StatesGroup, State
from aiogram.fsm.storage.memory import MemoryStorage

# REPORTLAB + Montserrat
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import cm
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
import os

# ---------------------------
# 1) Загрузим токен из .env
# ---------------------------
load_dotenv()
BOT_TOKEN = os.getenv("BOT_TOKEN")

bot = Bot(token=BOT_TOKEN)
dp = Dispatcher(storage=MemoryStorage())
router = Router()

# ---------------------------
# Регистрируем шрифт Montserrat
# ---------------------------
pdfmetrics.registerFont(TTFont('Montserrat', 'fonts/Montserrat-Regular.ttf'))


# ---------------------------
# 2) Клавиатуры
# ---------------------------

# Главное меню выбора языка
choose_language_kb = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="Создать анкету на русском")],
        [KeyboardButton(text="Создать анкету на английском")],
    ],
    resize_keyboard=True
)

# Кнопка "Назад" (чтобы вернуться в выбор языка)
back_to_lang_kb = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="Назад")],
    ],
    resize_keyboard=True
)

# Меню "Добавить данные" / "Завершить документ"
add_or_finish_kb = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="Добавить данные")],
        [KeyboardButton(text="Завершить создание документа")],
    ],
    resize_keyboard=True
)

# Меню "Добавить ещё" (или "Добавить опыт работы" / "Добавить опыт службы") / "Перейти к следующему шагу"
work_or_next_kb = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="Добавить опыт работы")],
        [KeyboardButton(text="Перейти к следующему шагу")],
    ],
    resize_keyboard=True
)

service_or_next_kb = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="Добавить опыт службы")],
        [KeyboardButton(text="Перейти к следующему шагу")],
    ],
    resize_keyboard=True
)

edu_or_next_kb = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="Добавить образование")],
        [KeyboardButton(text="Перейти к следующему шагу")],
    ],
    resize_keyboard=True
)

# Меню "Добавить блок доп. инф." / "Завершить"
finish_or_add_block_kb = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="Добавить блок доп. информации")],
        [KeyboardButton(text="Завершить")],
    ],
    resize_keyboard=True
)

# После генерации: "Внести исправления" / "Завершить"
after_generation_kb = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="Внести исправления")],
        [KeyboardButton(text="Завершить")],  # вместо "Отправить готовый документ"
    ],
    resize_keyboard=True
)

# Меню "Внести исправления": список кнопок редактирования
edit_menu_kb = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="Фотография 3x4"), KeyboardButton(text="Фотография в полный рост")],
        [KeyboardButton(text="Общая информация"), KeyboardButton(text="Опыт работы")],
        [KeyboardButton(text="Военная служба"), KeyboardButton(text="Образование")],
        [KeyboardButton(text="Дополнительная информация")],
    ],
    resize_keyboard=True
)


# ---------------------------
# 3) Состояния FSM
# ---------------------------
class FormStates(StatesGroup):
    CHOOSE_LANG = State()
    WAITING_PHOTO_34 = State()
    WAITING_PHOTO_FULL = State()
    WAITING_ADD_OR_FINISH = State()

    WAITING_BASIC_INFO = State()
    WAITING_WORK = State()
    WAITING_WORK_CHOICE = State()

    WAITING_MILITARY_DATA = State()
    WAITING_MILITARY_CHOICE = State()  # "Добавить опыт службы" / "Перейти к следующему шагу"

    WAITING_EDUCATION_DATA = State()
    WAITING_EDUCATION_CHOICE = State()

    WAITING_ADDITIONAL_DATA = State()
    WAITING_FINISH_OR_ADD_BLOCK = State()

    PDF_GENERATED = State()
    WAITING_EDIT = State()
    WAITING_EDIT_BLOCK = State()  # Когда выбрали, что редактировать


# ---------------------------
# 4) Логика
# ---------------------------
@router.message(CommandStart())
async def cmd_start(message: Message, state: FSMContext):
    """
    Показываем выбор языка (рус/англ). Очищаем данные.
    """
    await state.clear()
    await message.answer(
        "Привет! Это бот для создания анкет.\nВыберите язык анкеты:",
        reply_markup=choose_language_kb
    )
    await state.set_state(FormStates.CHOOSE_LANG)


@router.message(FormStates.CHOOSE_LANG, F.text == "Создать анкету на русском")
async def form_russian(message: Message, state: FSMContext):
    """
    Русский сценарий
    """
    # Сохраняем, что выбрали русский
    await state.update_data({
        "lang": "ru",
        "photo_3x4": None,
        "photo_full": None,
        "basic_info": {},
        "work_experience": [],
        "military_service": None,
        "education": [],
        "additional_info": None
    })

    # Просим фото 3x4
    await message.answer(
        "Вы выбрали анкету на русском.\n"
        "Пожалуйста, отправьте фотографию (как на паспорт) — 3/4.",
        reply_markup=back_to_lang_kb  # вместо кнопок "рус/англ" — даём "Назад"
    )
    await state.set_state(FormStates.WAITING_PHOTO_34)


@router.message(FormStates.CHOOSE_LANG, F.text == "Создать анкету на английском")
async def form_english(message: Message, state: FSMContext):
    """
    Английский сценарий (демо-коротко)
    """
    await state.update_data({
        "lang": "en",
        "photo_3x4": None,
        "photo_full": None,
        "basic_info": {},
        "work_experience": [],
        "military_service": None,
        "education": [],
        "additional_info": None
    })
    await message.answer(
        "You have chosen to fill the form in English.\n"
        "Please send a 3/4 photo (like on a passport).",
        reply_markup=back_to_lang_kb
    )
    await state.set_state(FormStates.WAITING_PHOTO_34)


@router.message(FormStates.CHOOSE_LANG, F.text == "Назад")
async def choose_lang_back(message: Message, state: FSMContext):
    # Если вдруг нажали "Назад" - но мы ещё в выборе языка
    await cmd_start(message, state)


@router.message(FormStates.WAITING_PHOTO_34, F.text == "Назад")
async def photo34_back(message: Message, state: FSMContext):
    # Вернуться к выбору языка
    await cmd_start(message, state)


@router.message(FormStates.WAITING_PHOTO_34, F.photo)
async def receive_photo_34(message: Message, state: FSMContext):
    # Сохраняем file_id
    file_id = message.photo[-1].file_id
    await state.update_data({"photo_3x4": file_id})

    await message.answer(
        "Фото 3/4 получено!\nТеперь отправьте фотографию сотрудника в полный рост.",
        reply_markup=back_to_lang_kb
    )
    await state.set_state(FormStates.WAITING_PHOTO_FULL)


@router.message(FormStates.WAITING_PHOTO_FULL, F.photo)
async def receive_photo_full(message: Message, state: FSMContext):
    file_id = message.photo[-1].file_id
    await state.update_data({"photo_full": file_id})

    # Предлагаем добавить данные или завершить
    await message.answer(
        "Фото в полный рост получено.\nТеперь вы можете добавить информацию или сразу завершить документ.",
        reply_markup=add_or_finish_kb
    )
    await state.set_state(FormStates.WAITING_ADD_OR_FINISH)


@router.message(FormStates.WAITING_PHOTO_FULL, F.text == "Назад")
async def photo_full_back(message: Message, state: FSMContext):
    # Вернуться к фото 3x4
    await form_russian(message, state)  # или form_english, если lang=en (нужно доп. логику)


@router.message(FormStates.WAITING_ADD_OR_FINISH, F.text == "Добавить данные")
async def add_data_start(message: Message, state: FSMContext):
    # Запрашиваем основную инфу
    await message.answer(
        "Пожалуйста, укажите дату и место рождения, место регистрации, рост, вес, семейное положение.\n\n"
        "Пример (каждое поле с новой строки!):\n"
        "01.01.1990\n"
        "Санкт-Петербург\n"
        "Москва (текущее место проживания)\n"
        "190\n"
        "90\n"
        "Женат\n\n"
        "Или нажмите «Пропустить».",
        # Убираем кнопки "Добавить" - пользователь просто вводит
        reply_markup=ReplyKeyboardMarkup(
            keyboard=[
                [KeyboardButton(text="Пропустить")],
            ],
            resize_keyboard=True
        )
    )
    await state.set_state(FormStates.WAITING_BASIC_INFO)


@router.message(FormStates.WAITING_ADD_OR_FINISH, F.text == "Завершить создание документа")
async def finish_early(message: Message, state: FSMContext):
    await generate_and_send_pdf(message, state)
    await state.set_state(FormStates.PDF_GENERATED)


# Если нажали что-то иное
@router.message(FormStates.WAITING_ADD_OR_FINISH)
async def unknown_add_or_finish(message: Message):
    await message.answer("Пожалуйста, используйте кнопки: «Добавить данные» или «Завершить создание документа».")


@router.message(FormStates.WAITING_BASIC_INFO, F.text == "Пропустить")
async def skip_basic_info(message: Message, state: FSMContext):
    await state.update_data({"basic_info": {
        "birth_date": "Пропущено",
        "registration": "Пропущено",
        "residence": "Пропущено",
        "height": "Пропущено",
        "weight": "Пропущено",
        "marital": "Пропущено"
    }})
    await ask_for_work(message, state)


@router.message(FormStates.WAITING_BASIC_INFO)
async def receive_basic_info(message: Message, state: FSMContext):
    lines = message.text.split("\n")
    if len(lines) < 6:
        await message.answer("Нужно 6 строк!")
        return
    # Сохраняем
    bdict = {
        "birth_date": lines[0].strip(),
        "registration": lines[1].strip(),
        "residence": lines[2].strip(),
        "height": lines[3].strip(),
        "weight": lines[4].strip(),
        "marital": lines[5].strip()
    }
    await state.update_data({"basic_info": bdict})
    await ask_for_work(message, state)


async def ask_for_work(message: Message, state: FSMContext):
    await message.answer(
        "Пожалуйста, укажите данные об опыте работы в следующем формате (5 строк, обязательно перенос строк!):\n\n"
        "1) Наименование работодателя\n"
        "2) Город места работы\n"
        "3) Период (например: 2010 2015)\n"
        "4) Должность\n"
        "5) Обязанности\n\n"
        "Или нажмите «Пропустить» чтобы перейти к следующему шагу.",
        reply_markup=ReplyKeyboardMarkup(
            keyboard=[
                [KeyboardButton(text="Пропустить")],
            ],
            resize_keyboard=True
        )
    )
    await state.set_state(FormStates.WAITING_WORK)


@router.message(FormStates.WAITING_WORK, F.text == "Пропустить")
async def skip_work(message: Message, state: FSMContext):
    await go_next_work(message, state)


@router.message(FormStates.WAITING_WORK)
async def receive_work(message: Message, state: FSMContext):
    lines = message.text.split("\n")
    if len(lines) < 5:
        await message.answer("Нужно 5 строк!")
        return
    data_ = await state.get_data()
    wlist = data_.get("work_experience", [])
    wdict = {
        "employer": lines[0].strip(),
        "city": lines[1].strip(),
        "period": lines[2].strip(),
        "position": lines[3].strip(),
        "duties": lines[4].strip()
    }
    wlist.append(wdict)
    await state.update_data({"work_experience": wlist})

    await message.answer(
        "Опыт работы добавлен. «Добавить опыт работы» или «Перейти к следующему шагу»?",
        reply_markup=work_or_next_kb
    )
    await state.set_state(FormStates.WAITING_WORK_CHOICE)


@router.message(FormStates.WAITING_WORK_CHOICE, F.text == "Добавить опыт работы")
async def add_more_work_exp(message: Message, state: FSMContext):
    await message.answer(
        "Введите ещё 5 строк или «Пропустить»",
        reply_markup=ReplyKeyboardMarkup(
            keyboard=[
                [KeyboardButton(text="Пропустить")],
            ],
            resize_keyboard=True
        )
    )
    await state.set_state(FormStates.WAITING_WORK)


@router.message(FormStates.WAITING_WORK_CHOICE, F.text == "Перейти к следующему шагу")
async def go_next_work(message: Message, state: FSMContext):
    # Военная служба
    await message.answer(
        "Пожалуйста, укажите данные о военной службе или нажмите «Пропустить».\n\n"
        "Формат (4 строки):\n"
        "1) Наименование подразделения\n"
        "2) Год начала (пробел) Год конца службы\n"
        "3) Звание\n"
        "4) Обязанности/Примечания\n",
        reply_markup=ReplyKeyboardMarkup(
            keyboard=[
                [KeyboardButton(text="Пропустить")],
            ],
            resize_keyboard=True
        )
    )
    await state.set_state(FormStates.WAITING_MILITARY_DATA)


@router.message(FormStates.WAITING_WORK_CHOICE)
async def unknown_work_choice(message: Message):
    await message.answer("Кнопки: «Добавить опыт работы» или «Перейти к следующему шагу».")


@router.message(FormStates.WAITING_MILITARY_DATA, F.text == "Пропустить")
async def skip_military(message: Message, state: FSMContext):
    await state.update_data({"military_service": None})
    await ask_for_education(message, state)


@router.message(FormStates.WAITING_MILITARY_DATA)
async def receive_military(message: Message, state: FSMContext):
    lines = message.text.split("\n")
    if len(lines) < 4:
        await message.answer("Нужно 4 строки!")
        return
    ms_dict = {
        "subdivision": lines[0].strip(),
        "period": lines[1].strip(),
        "rank": lines[2].strip(),
        "notes": lines[3].strip()
    }
    await state.update_data({"military_service": ms_dict})
    await message.answer(
        "Военная служба добавлена. «Добавить опыт службы» или «Перейти к следующему шагу»?",
        reply_markup=service_or_next_kb
    )
    await state.set_state(FormStates.WAITING_MILITARY_CHOICE)


@router.message(FormStates.WAITING_MILITARY_CHOICE, F.text == "Добавить опыт службы")
async def add_more_military(message: Message, state: FSMContext):
    await message.answer(
        "Введите ещё 4 строки или «Пропустить»",
        reply_markup=ReplyKeyboardMarkup(
            keyboard=[
                [KeyboardButton(text="Пропустить")],
            ],
            resize_keyboard=True
        )
    )
    await state.set_state(FormStates.WAITING_MILITARY_DATA)


@router.message(FormStates.WAITING_MILITARY_CHOICE, F.text == "Перейти к следующему шагу")
async def go_next_military(message: Message, state: FSMContext):
    await ask_for_education(message, state)


@router.message(FormStates.WAITING_MILITARY_CHOICE)
async def unknown_military_choice(message: Message):
    await message.answer("Кнопки: «Добавить опыт службы» или «Перейти к следующему шагу».")


async def ask_for_education(message: Message, state: FSMContext):
    await message.answer(
        "Пожалуйста, укажите данные об образовании (или нажмите «Пропустить»).\n\n"
        "Формат (4 строки):\n"
        "1) Наименование учебного учреждения\n"
        "2) Год начала (пробел) Год конца учёбы\n"
        "3) Вид образования (высшее, среднее, ...)\n"
        "4) Специальность\n",
        reply_markup=ReplyKeyboardMarkup(
            keyboard=[
                [KeyboardButton(text="Пропустить")],
            ],
            resize_keyboard=True
        )
    )
    await state.set_state(FormStates.WAITING_EDUCATION_DATA)


@router.message(FormStates.WAITING_EDUCATION_DATA, F.text == "Пропустить")
async def skip_education(message: Message, state: FSMContext):
    await go_next_education(message, state)


@router.message(FormStates.WAITING_EDUCATION_DATA)
async def receive_education(message: Message, state: FSMContext):
    lines = message.text.split("\n")
    if len(lines) < 4:
        await message.answer("Нужно 4 строки!")
        return
    data_ = await state.get_data()
    edu_list = data_.get("education", [])
    e_dict = {
        "institution": lines[0].strip(),
        "period": lines[1].strip(),
        "type": lines[2].strip(),
        "specialty": lines[3].strip()
    }
    edu_list.append(e_dict)
    await state.update_data({"education": edu_list})
    await message.answer(
        "Образование добавлено. «Добавить образование» или «Перейти к следующему шагу»?",
        reply_markup=edu_or_next_kb
    )
    await state.set_state(FormStates.WAITING_EDUCATION_CHOICE)


@router.message(FormStates.WAITING_EDUCATION_CHOICE, F.text == "Добавить образование")
async def add_more_education(message: Message, state: FSMContext):
    await message.answer(
        "Введите ещё 4 строки или «Пропустить».",
        reply_markup=ReplyKeyboardMarkup(
            keyboard=[
                [KeyboardButton(text="Пропустить")],
            ],
            resize_keyboard=True
        )
    )
    await state.set_state(FormStates.WAITING_EDUCATION_DATA)


@router.message(FormStates.WAITING_EDUCATION_CHOICE, F.text == "Перейти к следующему шагу")
async def go_next_education(message: Message, state: FSMContext):
    # Дополнительные данные
    await message.answer(
        "Дополнительные данные (навыки, характеристики) или «Пропустить».",
        reply_markup=ReplyKeyboardMarkup(
            keyboard=[
                [KeyboardButton(text="Пропустить")],
            ],
            resize_keyboard=True
        )
    )
    await state.set_state(FormStates.WAITING_ADDITIONAL_DATA)


@router.message(FormStates.WAITING_EDUCATION_CHOICE)
async def unknown_education_choice(message: Message):
    await message.answer("Кнопки: «Добавить образование» или «Перейти к следующему шагу».")


@router.message(FormStates.WAITING_ADDITIONAL_DATA, F.text == "Пропустить")
async def skip_additional(message: Message, state: FSMContext):
    await state.update_data({"additional_info": "Пропущено"})
    await message.answer(
        "Можете «Завершить» (создать PDF) или «Добавить блок доп. информации».",
        reply_markup=finish_or_add_block_kb
    )
    await state.set_state(FormStates.WAITING_FINISH_OR_ADD_BLOCK)


@router.message(FormStates.WAITING_ADDITIONAL_DATA)
async def receive_additional(message: Message, state: FSMContext):
    await state.update_data({"additional_info": message.text})
    await message.answer(
        "Можете «Завершить» (создать PDF) или «Добавить блок доп. информации».",
        reply_markup=finish_or_add_block_kb
    )
    await state.set_state(FormStates.WAITING_FINISH_OR_ADD_BLOCK)


@router.message(FormStates.WAITING_FINISH_OR_ADD_BLOCK, F.text == "Завершить")
async def finish_document(message: Message, state: FSMContext):
    await generate_and_send_pdf(message, state)
    await state.set_state(FormStates.PDF_GENERATED)


@router.message(FormStates.WAITING_FINISH_OR_ADD_BLOCK, F.text == "Добавить блок доп. информации")
async def add_extra_block(message: Message, state: FSMContext):
    await message.answer("Демо: тут можно добавить новые поля или вернуться к шагам.")


@router.message(FormStates.WAITING_FINISH_OR_ADD_BLOCK)
async def unknown_finish_or_add_block(message: Message):
    await message.answer("Кнопки: «Завершить» или «Добавить блок доп. информации».")


# ---------------------------
# После генерации PDF
# ---------------------------
@router.message(FormStates.PDF_GENERATED, F.text == "Внести исправления")
async def edit_document(message: Message, state: FSMContext):
    await message.answer(
        "Что хотите исправить?",
        reply_markup=edit_menu_kb
    )
    await state.set_state(FormStates.WAITING_EDIT)


@router.message(FormStates.PDF_GENERATED, F.text == "Завершить")
async def finalize_doc(message: Message, state: FSMContext):
    await message.answer("Документ сформирован окончательно. Завершаем.", reply_markup=ReplyKeyboardRemove())
    await state.clear()


@router.message(FormStates.PDF_GENERATED)
async def unknown_after_pdf(message: Message):
    await message.answer("«Внести исправления» или «Завершить».")


@router.message(FormStates.WAITING_EDIT)
async def edit_which_block(message: Message, state: FSMContext):
    """
    Демо: по нажатию на одну из кнопок "Фотография 3x4" / "Военная служба" / ...
    возвращаемся к нужному состоянию.
    """
    txt = message.text

    if txt == "Фотография 3x4":
        await message.answer("Пришлите новое фото 3x4.")
        await state.set_state(FormStates.WAITING_PHOTO_34)
    elif txt == "Фотография в полный рост":
        await message.answer("Пришлите новое фото в полный рост.")
        await state.set_state(FormStates.WAITING_PHOTO_FULL)
    elif txt == "Общая информация":
        await add_data_start(message, state)
    elif txt == "Опыт работы":
        await ask_for_work(message, state)
    elif txt == "Военная служба":
        await go_next_work(message, state)  # Т.е. перейдём к военной службе
    elif txt == "Образование":
        await ask_for_education(message, state)
    elif txt == "Дополнительная информация":
        await message.answer(
            "Дополнительные данные (навыки, характеристики) или «Пропустить».",
            reply_markup=ReplyKeyboardMarkup(
                keyboard=[
                    [KeyboardButton(text="Пропустить")],
                ],
                resize_keyboard=True
            )
        )
        await state.set_state(FormStates.WAITING_ADDITIONAL_DATA)
    else:
        await message.answer("Неизвестный блок. Выберите из списка.")
        return

    # Как только блок до заполнится, снова сгенерируем PDF
    # (см. соответствующий хендлер).


# ---------------------------
# Генерация PDF (с Montserrat)
# ---------------------------
async def generate_and_send_pdf(message: Message, state: FSMContext):
    data = await state.get_data()
    pdf_buffer = await generate_pdf(bot, data)

    pdf_buffer.seek(0)
    pdf_bytes = pdf_buffer.read()
    pdf_file = BufferedInputFile(pdf_bytes, filename="Anketa.pdf")

    await message.answer_document(
        document=pdf_file,
        caption="Готовый документ (PDF)."
    )

    await message.answer(
        "Хотите внести исправления или «Завершить»?",
        reply_markup=after_generation_kb
    )


async def generate_pdf(bot: Bot, data: dict):
    """
    Формируем PDF на русском/английском (в зависимости от data["lang"]),
    со шрифтом Montserrat и нужными разделами.
    Для краткости сделаем только русский пример,
    но если data["lang"] == "en" - можно переключить тексты на английские.
    """
    buffer = BytesIO()

    # Настраиваем документ
    doc = SimpleDocTemplate(
        buffer,
        pagesize=A4,
        leftMargin=2*cm,
        rightMargin=2*cm,
        topMargin=2*cm,
        bottomMargin=2*cm
    )

    styles = getSampleStyleSheet()

    # Подключаем Montserrat (уже зарегистрирован выше)
    style_normal = styles['Normal']
    style_normal.fontName = 'Montserrat'
    style_normal.fontSize = 10

    style_title = styles['Title']
    style_title.fontName = 'Montserrat'
    style_title.fontSize = 16

    style_heading = ParagraphStyle(
        'Heading',
        parent=style_normal,
        fontName='Montserrat',
        fontSize=12,
        spaceBefore=10,
        spaceAfter=5
    )

    lang = data.get("lang","ru")

    elements = []

    if lang == "ru":
        # Русские заголовки
        full_name = data.get("basic_info", {}).get("full_name", "Иванов Иван Иванович")
        position = "Охранник"
        title_para = Paragraph(f"<b>{full_name}</b><br/>{position}", style_title)
        elements.append(title_para)
        elements.append(Spacer(1, 0.8*cm))

        # Основная информация, Опыт работы, ...
        # (аналогично тому, что вы делали; использовать Montserrat)
        # Здесь для краткости можно вставить тот же код, что раньше,
        # только менять style_normal -> Montserrat.

        # ...Пример...
        elements.append(Paragraph("Основная информация:", style_heading))
        # И т.д.

    else:
        # Если выбрали английский
        elements.append(Paragraph("<b>John Smith</b><br/>Security guard", style_title))
        # ... ваш английский вариант

    # Для примера вставим упрощённо:
    # (в реальном коде выводим всё, как в русском сценарии, но на английском)

    doc.build(elements)
    buffer.seek(0)
    return buffer


# ---------------------------
# Запуск бота
# ---------------------------
dp.include_router(router)

async def main():
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())