import os
import asyncio
from io import BytesIO

from dotenv import load_dotenv
from aiogram import Bot, Dispatcher, Router, F
from aiogram.types import (
    Message, ReplyKeyboardMarkup, KeyboardButton,
    ReplyKeyboardRemove, BufferedInputFile
)
from aiogram.filters import CommandStart
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import StatesGroup, State
from aiogram.fsm.storage.memory import MemoryStorage

# REPORTLAB + Montserrat
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Image
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import cm
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle


# --------------------------------------------------
# Инициализация
# --------------------------------------------------
load_dotenv()
BOT_TOKEN = os.getenv("BOT_TOKEN")

bot = Bot(token=BOT_TOKEN)
dp = Dispatcher(storage=MemoryStorage())
router = Router()

# Регистрируем шрифт Montserrat (должен лежать в папке fonts/Montserrat-Regular.ttf)
pdfmetrics.registerFont(TTFont('Montserrat', '../fonts/Montserrat-Regular.ttf'))

# Создаём папку для фото
os.makedirs("photos", exist_ok=True)


# --------------------------------------------------
# Клавиатуры
# --------------------------------------------------

# Главное меню языка
choose_language_kb = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="Создать анкету на русском")],
        [KeyboardButton(text="Create form in English")],
    ],
    resize_keyboard=True
)

# Кнопка "Назад" (и "Back") вместе
back_to_lang_kb = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="Назад"), KeyboardButton(text="Back")]
    ],
    resize_keyboard=True
)

# Меню "Добавить / Завершить" (рус)
add_or_finish_kb_ru = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="Добавить данные")],
        [KeyboardButton(text="Завершить создание документа")],
    ],
    resize_keyboard=True
)
# (англ)
add_or_finish_kb_en = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="Add data")],
        [KeyboardButton(text="Finish document")],
    ],
    resize_keyboard=True
)

# "Добавить опыт работы" / "Следующий шаг" (рус)
work_or_next_kb_ru = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="Добавить опыт работы")],
        [KeyboardButton(text="Перейти к следующему шагу")],
    ],
    resize_keyboard=True
)
# (англ)
work_or_next_kb_en = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="Add work experience")],
        [KeyboardButton(text="Go to next step")],
    ],
    resize_keyboard=True
)

# Военная служба (рус)
service_or_next_kb_ru = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="Добавить опыт службы")],
        [KeyboardButton(text="Перейти к следующему шагу")],
    ],
    resize_keyboard=True
)
# (англ)
service_or_next_kb_en = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="Add military service")],
        [KeyboardButton(text="Go to next step")],
    ],
    resize_keyboard=True
)

# Образование (рус)
edu_or_next_kb_ru = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="Добавить образование")],
        [KeyboardButton(text="Перейти к следующему шагу")],
    ],
    resize_keyboard=True
)
# (англ)
edu_or_next_kb_en = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="Add education")],
        [KeyboardButton(text="Go to next step")],
    ],
    resize_keyboard=True
)

# "Добавить блок доп. инф." / "Завершить" (рус)
finish_or_add_block_kb_ru = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="Добавить блок доп. информации")],
        [KeyboardButton(text="Завершить")],
    ],
    resize_keyboard=True
)
# (англ)
finish_or_add_block_kb_en = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="Add extra info block")],
        [KeyboardButton(text="Finish")],
    ],
    resize_keyboard=True
)

# После генерации PDF: "Внести исправления" / "Завершить"
after_generation_kb_ru = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="Внести исправления")],
        [KeyboardButton(text="Завершить")],
    ],
    resize_keyboard=True
)
after_generation_kb_en = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="Edit data")],
        [KeyboardButton(text="Finish")],
    ],
    resize_keyboard=True
)

# Меню "Внести исправления" (рус)
edit_menu_kb_ru = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="Фотография 3x4"), KeyboardButton(text="Фотография в полный рост")],
        [KeyboardButton(text="Общая информация"), KeyboardButton(text="Опыт работы")],
        [KeyboardButton(text="Военная служба"), KeyboardButton(text="Образование")],
        [KeyboardButton(text="Дополнительная информация")],
    ],
    resize_keyboard=True
)
# (англ)
edit_menu_kb_en = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="Photo 3x4"), KeyboardButton(text="Full height photo")],
        [KeyboardButton(text="Basic info"), KeyboardButton(text="Work experience")],
        [KeyboardButton(text="Military service"), KeyboardButton(text="Education")],
        [KeyboardButton(text="Additional info")],
    ],
    resize_keyboard=True
)


# --------------------------------------------------
# Состояния
# --------------------------------------------------
class FormStates(StatesGroup):
    CHOOSE_LANG = State()
    WAITING_PHOTO_34 = State()
    WAITING_PHOTO_FULL = State()
    WAITING_ADD_OR_FINISH = State()

    WAITING_BASIC_INFO = State()
    WAITING_WORK = State()
    WAITING_WORK_CHOICE = State()

    WAITING_MILITARY_DATA = State()
    WAITING_MILITARY_CHOICE = State()

    WAITING_EDUCATION_DATA = State()
    WAITING_EDUCATION_CHOICE = State()

    WAITING_ADDITIONAL_DATA = State()
    WAITING_FINISH_OR_ADD_BLOCK = State()

    PDF_GENERATED = State()
    WAITING_EDIT = State()

# Утилита получения языка
async def get_lang(state: FSMContext) -> str:
    data = await state.get_data()
    return data.get("lang", "ru")


# --------------------------------------------------
# Старт: выбор языка
# --------------------------------------------------
@router.message(CommandStart())
async def cmd_start(message: Message, state: FSMContext):
    await state.clear()
    await message.answer(
        "Привет! Это бот для создания анкет.\nВыберите язык анкеты:",
        reply_markup=choose_language_kb
    )
    await state.set_state(FormStates.CHOOSE_LANG)

@router.message(FormStates.CHOOSE_LANG, F.text == "Создать анкету на русском")
async def form_russian(message: Message, state: FSMContext):
    await state.update_data({
        "lang": "ru",
        "photo_3x4": None,
        "photo_full": None,
        "basic_info": {},
        "work_experience": [],
        "military_service": None,
        "education": [],
        "additional_info": None
    })
    await message.answer(
        "Вы выбрали анкету на русском.\n"
        "Пожалуйста, отправьте фотографию (как на паспорт) — 3×4.",
        reply_markup=back_to_lang_kb
    )
    await state.set_state(FormStates.WAITING_PHOTO_34)

@router.message(FormStates.CHOOSE_LANG, F.text == "Create form in English")
async def form_english(message: Message, state: FSMContext):
    await state.update_data({
        "lang": "en",
        "photo_3x4": None,
        "photo_full": None,
        "basic_info": {},
        "work_experience": [],
        "military_service": None,
        "education": [],
        "additional_info": None
    })
    await message.answer(
        "You have chosen to fill the form in English.\n"
        "Please send a 3×4 photo (like on a passport).",
        reply_markup=back_to_lang_kb
    )
    await state.set_state(FormStates.WAITING_PHOTO_34)

@router.message(FormStates.CHOOSE_LANG, F.text.in_(["Назад", "Back"]))
async def choose_lang_back(message: Message, state: FSMContext):
    await cmd_start(message, state)


# --------------------------------------------------
# Фото 3×4
# --------------------------------------------------
@router.message(FormStates.WAITING_PHOTO_34, F.text.in_(["Назад", "Back"]))
async def photo34_back(message: Message, state: FSMContext):
    await cmd_start(message, state)

@router.message(FormStates.WAITING_PHOTO_34, F.photo)
async def receive_photo_34(message: Message, state: FSMContext):
    file_id = message.photo[-1].file_id
    await state.update_data({"photo_3x4": file_id})
    lang = await get_lang(state)

    if lang == "ru":
        text_msg = "Фото 3×4 получено!\nТеперь отправьте фотографию в полный рост."
    else:
        text_msg = "3×4 photo received!\nNow send a full-height photo."

    await message.answer(text_msg, reply_markup=back_to_lang_kb)
    await state.set_state(FormStates.WAITING_PHOTO_FULL)

# --------------------------------------------------
# Фото в полный рост
# --------------------------------------------------
@router.message(FormStates.WAITING_PHOTO_FULL, F.text.in_(["Назад", "Back"]))
async def photo_full_back(message: Message, state: FSMContext):
    lang = await get_lang(state)
    if lang == "ru":
        await form_russian(message, state)
    else:
        await form_english(message, state)

@router.message(FormStates.WAITING_PHOTO_FULL, F.photo)
async def receive_photo_full(message: Message, state: FSMContext):
    file_id = message.photo[-1].file_id
    await state.update_data({"photo_full": file_id})

    lang = await get_lang(state)
    if lang == "ru":
        text_msg = (
            "Фото в полный рост получено.\n"
            "Теперь вы можете добавить данные или завершить документ."
        )
        kb = add_or_finish_kb_ru
    else:
        text_msg = (
            "Full-height photo received.\n"
            "Now you can add data or finish the document."
        )
        kb = add_or_finish_kb_en

    await message.answer(text_msg, reply_markup=kb)
    await state.set_state(FormStates.WAITING_ADD_OR_FINISH)


# --------------------------------------------------
# "Добавить данные" или "Завершить создание документа"
# --------------------------------------------------
@router.message(FormStates.WAITING_ADD_OR_FINISH)
async def add_or_finish(message: Message, state: FSMContext):
    txt = message.text
    lang = await get_lang(state)

    if lang == "ru":
        if txt == "Добавить данные":
            await ask_basic_info_ru(message, state)
        elif txt == "Завершить создание документа":
            await generate_and_send_pdf(message, state)
            await message.answer(
                "Документ сформирован. Что делаем?",
                reply_markup=after_generation_kb_ru
            )
            await state.set_state(FormStates.PDF_GENERATED)
        else:
            await message.answer("Выберите: «Добавить данные» или «Завершить создание документа».")

    else:
        # Англ
        if txt == "Add data":
            await ask_basic_info_en(message, state)
        elif txt == "Finish document":
            await generate_and_send_pdf(message, state)
            await message.answer(
                "Document generated. What's next?",
                reply_markup=after_generation_kb_en
            )
            await state.set_state(FormStates.PDF_GENERATED)
        else:
            await message.answer("Please choose: 'Add data' or 'Finish document'.")


# --------------------------------------------------
# Запрос основной инфы
# --------------------------------------------------
async def ask_basic_info_ru(message: Message, state: FSMContext):
    await message.answer(
        "Укажите дату рождения, место регистрации, текущее место жительства, рост, вес, семейное положение.\n"
        "(6 строк, одна строка — один пункт)\n\nИли нажмите «Пропустить».",
        reply_markup=ReplyKeyboardMarkup(
            keyboard=[[KeyboardButton(text="Пропустить")]],
            resize_keyboard=True
        )
    )
    await state.set_state(FormStates.WAITING_BASIC_INFO)

async def ask_basic_info_en(message: Message, state: FSMContext):
    await message.answer(
        "Please enter (6 lines): birth date, registration place, current residence, height, weight, marital status.\n"
        "Or press 'Skip'.",
        reply_markup=ReplyKeyboardMarkup(
            keyboard=[[KeyboardButton(text="Skip")]],
            resize_keyboard=True
        )
    )
    await state.set_state(FormStates.WAITING_BASIC_INFO)

@router.message(FormStates.WAITING_BASIC_INFO)
async def receive_basic_info(message: Message, state: FSMContext):
    txt = message.text
    lang = await get_lang(state)

    # Пропустить
    if lang == "ru" and txt == "Пропустить":
        await state.update_data({"basic_info": {
            "birth_date": "Пропущено",
            "registration": "Пропущено",
            "residence": "Пропущено",
            "height": "Пропущено",
            "weight": "Пропущено",
            "marital": "Пропущено"
        }})
        await ask_work_exp(message, state)
        return
    elif lang == "en" and txt == "Skip":
        await state.update_data({"basic_info": {
            "birth_date": "Skipped",
            "registration": "Skipped",
            "residence": "Skipped",
            "height": "Skipped",
            "weight": "Skipped",
            "marital": "Skipped"
        }})
        await ask_work_exp(message, state)
        return

    lines = txt.split("\n")
    if len(lines) < 6:
        if lang == "ru":
            await message.answer("Нужно 6 строк!")
        else:
            await message.answer("Need 6 lines!")
        return

    bdict = {
        "birth_date": lines[0].strip(),
        "registration": lines[1].strip(),
        "residence": lines[2].strip(),
        "height": lines[3].strip(),
        "weight": lines[4].strip(),
        "marital": lines[5].strip()
    }
    await state.update_data({"basic_info": bdict})

    await ask_work_exp(message, state)


# --------------------------------------------------
# Опыт работы
# --------------------------------------------------
async def ask_work_exp(message: Message, state: FSMContext):
    lang = await get_lang(state)
    if lang == "ru":
        t = (
            "Укажите опыт работы (5 строк) или «Пропустить»:\n"
            "1) Работодатель\n"
            "2) Город\n"
            "3) Период (2010 2015)\n"
            "4) Должность\n"
            "5) Обязанности\n"
        )
        kb = ReplyKeyboardMarkup(
            keyboard=[[KeyboardButton(text="Пропустить")]],
            resize_keyboard=True
        )
    else:
        t = (
            "Enter work experience (5 lines) or 'Skip':\n"
            "1) Employer\n"
            "2) City\n"
            "3) Period\n"
            "4) Position\n"
            "5) Duties\n"
        )
        kb = ReplyKeyboardMarkup(
            keyboard=[[KeyboardButton(text="Skip")]],
            resize_keyboard=True
        )

    await message.answer(t, reply_markup=kb)
    await state.set_state(FormStates.WAITING_WORK)

@router.message(FormStates.WAITING_WORK)
async def receive_work_exp(message: Message, state: FSMContext):
    txt = message.text
    lang = await get_lang(state)

    # Пропустить
    if (lang == "ru" and txt == "Пропустить") or (lang == "en" and txt == "Skip"):
        await go_next_work(message, state)
        return

    lines = txt.split("\n")
    if len(lines) < 5:
        if lang == "ru":
            await message.answer("Нужно 5 строк!")
        else:
            await message.answer("Need 5 lines!")
        return

    data_ = await state.get_data()
    wlist = data_.get("work_experience", [])
    wdict = {
        "employer": lines[0].strip(),
        "city": lines[1].strip(),
        "period": lines[2].strip(),
        "position": lines[3].strip(),
        "duties": lines[4].strip(),
    }
    wlist.append(wdict)
    await state.update_data({"work_experience": wlist})

    if lang == "ru":
        txt_ = "Опыт работы добавлен. «Добавить опыт работы» или «Перейти к следующему шагу»?"
        kb = work_or_next_kb_ru
    else:
        txt_ = "Work experience added. 'Add work experience' or 'Go to next step'?"
        kb = work_or_next_kb_en

    await message.answer(txt_, reply_markup=kb)
    await state.set_state(FormStates.WAITING_WORK_CHOICE)

@router.message(FormStates.WAITING_WORK_CHOICE)
async def work_choice(message: Message, state: FSMContext):
    txt = message.text
    lang = await get_lang(state)

    if lang == "ru":
        if txt == "Добавить опыт работы":
            await message.answer(
                "Введите ещё 5 строк или «Пропустить».",
                reply_markup=ReplyKeyboardMarkup(
                    keyboard=[[KeyboardButton(text="Пропустить")]],
                    resize_keyboard=True
                )
            )
            await state.set_state(FormStates.WAITING_WORK)
        elif txt == "Перейти к следующему шагу":
            await ask_military(message, state)
        else:
            await message.answer("Выберите «Добавить опыт работы» или «Перейти к следующему шагу».")

    else:
        if txt == "Add work experience":
            await message.answer(
                "Enter another 5 lines or 'Skip'.",
                reply_markup=ReplyKeyboardMarkup(
                    keyboard=[[KeyboardButton(text="Skip")]],
                    resize_keyboard=True
                )
            )
            await state.set_state(FormStates.WAITING_WORK)
        elif txt == "Go to next step":
            await ask_military(message, state)
        else:
            await message.answer("Choose 'Add work experience' or 'Go to next step'.")


# --------------------------------------------------
# Военная служба
# --------------------------------------------------
async def go_next_work(message: Message, state: FSMContext):
    await ask_military(message, state)

async def ask_military(message: Message, state: FSMContext):
    lang = await get_lang(state)
    if lang == "ru":
        t = (
            "Данные о военной службе (4 строки) или «Пропустить»:\n"
            "1) Подразделение\n"
            "2) Период (2010 2012)\n"
            "3) Звание\n"
            "4) Обязанности/Примечания\n"
        )
        kb = ReplyKeyboardMarkup(
            keyboard=[[KeyboardButton(text="Пропустить")]],
            resize_keyboard=True
        )
    else:
        t = (
            "Enter military service (4 lines) or 'Skip':\n"
            "1) Subdivision\n"
            "2) Period\n"
            "3) Rank\n"
            "4) Duties/Notes\n"
        )
        kb = ReplyKeyboardMarkup(
            keyboard=[[KeyboardButton(text="Skip")]],
            resize_keyboard=True
        )

    await message.answer(t, reply_markup=kb)
    await state.set_state(FormStates.WAITING_MILITARY_DATA)

@router.message(FormStates.WAITING_MILITARY_DATA)
async def receive_military(message: Message, state: FSMContext):
    txt = message.text
    lang = await get_lang(state)

    if (lang == "ru" and txt == "Пропустить") or (lang == "en" and txt == "Skip"):
        await state.update_data({"military_service": None})
        await ask_education(message, state)
        return

    lines = txt.split("\n")
    if len(lines) < 4:
        if lang == "ru":
            await message.answer("Нужно 4 строки!")
        else:
            await message.answer("Need 4 lines!")
        return

    ms = {
        "subdivision": lines[0].strip(),
        "period": lines[1].strip(),
        "rank": lines[2].strip(),
        "notes": lines[3].strip(),
    }
    await state.update_data({"military_service": ms})

    if lang == "ru":
        t_ = "Военная служба добавлена. «Добавить опыт службы» или «Перейти к следующему шагу»?"
        kb_ = service_or_next_kb_ru
    else:
        t_ = "Military service added. 'Add military service' or 'Go to next step'?"
        kb_ = service_or_next_kb_en

    await message.answer(t_, reply_markup=kb_)
    await state.set_state(FormStates.WAITING_MILITARY_CHOICE)

@router.message(FormStates.WAITING_MILITARY_CHOICE)
async def military_choice(message: Message, state: FSMContext):
    txt = message.text
    lang = await get_lang(state)

    if lang == "ru":
        if txt == "Добавить опыт службы":
            await message.answer(
                "Введите ещё 4 строки или «Пропустить».",
                reply_markup=ReplyKeyboardMarkup(
                    keyboard=[[KeyboardButton(text="Пропустить")]],
                    resize_keyboard=True
                )
            )
            await state.set_state(FormStates.WAITING_MILITARY_DATA)
        elif txt == "Перейти к следующему шагу":
            await ask_education(message, state)
        else:
            await message.answer("«Добавить опыт службы» или «Перейти к следующему шагу».")

    else:
        if txt == "Add military service":
            await message.answer(
                "Enter another 4 lines or 'Skip'.",
                reply_markup=ReplyKeyboardMarkup(
                    keyboard=[[KeyboardButton(text="Skip")]],
                    resize_keyboard=True
                )
            )
            await state.set_state(FormStates.WAITING_MILITARY_DATA)
        elif txt == "Go to next step":
            await ask_education(message, state)
        else:
            await message.answer("Buttons: 'Add military service' or 'Go to next step'.")


# --------------------------------------------------
# Образование
# --------------------------------------------------
async def ask_education(message: Message, state: FSMContext):
    lang = await get_lang(state)
    if lang == "ru":
        t = (
            "Образование (4 строки) или «Пропустить»:\n"
            "1) Учебное учреждение\n"
            "2) Период\n"
            "3) Вид образования\n"
            "4) Специальность\n"
        )
        kb = ReplyKeyboardMarkup(
            keyboard=[[KeyboardButton(text="Пропустить")]],
            resize_keyboard=True
        )
    else:
        t = (
            "Education (4 lines) or 'Skip':\n"
            "1) Institution\n"
            "2) Period\n"
            "3) Type\n"
            "4) Specialty\n"
        )
        kb = ReplyKeyboardMarkup(
            keyboard=[[KeyboardButton(text="Skip")]],
            resize_keyboard=True
        )
    await message.answer(t, reply_markup=kb)
    await state.set_state(FormStates.WAITING_EDUCATION_DATA)

@router.message(FormStates.WAITING_EDUCATION_DATA)
async def receive_education(message: Message, state: FSMContext):
    txt = message.text
    lang = await get_lang(state)

    if (lang == "ru" and txt == "Пропустить") or (lang == "en" and txt == "Skip"):
        await go_next_education(message, state)
        return

    lines = txt.split("\n")
    if len(lines) < 4:
        if lang == "ru":
            await message.answer("Нужно 4 строки!")
        else:
            await message.answer("Need 4 lines!")
        return

    data_ = await state.get_data()
    edu_list = data_.get("education", [])
    e_dict = {
        "institution": lines[0].strip(),
        "period": lines[1].strip(),
        "type": lines[2].strip(),
        "specialty": lines[3].strip()
    }
    edu_list.append(e_dict)
    await state.update_data({"education": edu_list})

    if lang == "ru":
        txt_ = "Образование добавлено. «Добавить образование» или «Перейти к следующему шагу»?"
        kb_ = edu_or_next_kb_ru
    else:
        txt_ = "Education added. 'Add education' or 'Go to next step'?"
        kb_ = edu_or_next_kb_en

    await message.answer(txt_, reply_markup=kb_)
    await state.set_state(FormStates.WAITING_EDUCATION_CHOICE)

@router.message(FormStates.WAITING_EDUCATION_CHOICE)
async def education_choice(message: Message, state: FSMContext):
    txt = message.text
    lang = await get_lang(state)

    if lang == "ru":
        if txt == "Добавить образование":
            await message.answer(
                "Введите ещё 4 строки или «Пропустить».",
                reply_markup=ReplyKeyboardMarkup(
                    keyboard=[[KeyboardButton(text="Пропустить")]],
                    resize_keyboard=True
                )
            )
            await state.set_state(FormStates.WAITING_EDUCATION_DATA)
        elif txt == "Перейти к следующему шагу":
            await ask_additional(message, state)
        else:
            await message.answer("«Добавить образование» или «Перейти к следующему шагу».")

    else:
        if txt == "Add education":
            await message.answer(
                "Enter another 4 lines or 'Skip'.",
                reply_markup=ReplyKeyboardMarkup(
                    keyboard=[[KeyboardButton(text="Skip")]],
                    resize_keyboard=True
                )
            )
            await state.set_state(FormStates.WAITING_EDUCATION_DATA)
        elif txt == "Go to next step":
            await ask_additional(message, state)
        else:
            await message.answer("'Add education' or 'Go to next step'.")


# --------------------------------------------------
# Дополнительная информация
# --------------------------------------------------
async def go_next_education(message: Message, state: FSMContext):
    await ask_additional(message, state)

async def ask_additional(message: Message, state: FSMContext):
    lang = await get_lang(state)
    if lang == "ru":
        text_ = "Дополнительные данные (навыки, характеристики) или «Пропустить»."
        kb_ = ReplyKeyboardMarkup(
            keyboard=[[KeyboardButton(text="Пропустить")]],
            resize_keyboard=True
        )
    else:
        text_ = "Additional info (skills, etc.) or 'Skip'."
        kb_ = ReplyKeyboardMarkup(
            keyboard=[[KeyboardButton(text="Skip")]],
            resize_keyboard=True
        )

    await message.answer(text_, reply_markup=kb_)
    await state.set_state(FormStates.WAITING_ADDITIONAL_DATA)

@router.message(FormStates.WAITING_ADDITIONAL_DATA)
async def receive_additional(message: Message, state: FSMContext):
    txt = message.text
    lang = await get_lang(state)

    if lang == "ru" and txt == "Пропустить":
        await state.update_data({"additional_info": "Пропущено"})
        await finish_or_add_block_ru(message, state)
        return
    elif lang == "en" and txt == "Skip":
        await state.update_data({"additional_info": "Skipped"})
        await finish_or_add_block_en(message, state)
        return

    await state.update_data({"additional_info": txt})
    if lang == "ru":
        await finish_or_add_block_ru(message, state)
    else:
        await finish_or_add_block_en(message, state)

async def finish_or_add_block_ru(message: Message, state: FSMContext):
    await message.answer(
        "Можете «Завершить» (создать PDF) или «Добавить блок доп. информации».",
        reply_markup=finish_or_add_block_kb_ru
    )
    await state.set_state(FormStates.WAITING_FINISH_OR_ADD_BLOCK)

async def finish_or_add_block_en(message: Message, state: FSMContext):
    await message.answer(
        "You can 'Finish' (create PDF) or 'Add extra info block'.",
        reply_markup=finish_or_add_block_kb_en
    )
    await state.set_state(FormStates.WAITING_FINISH_OR_ADD_BLOCK)

@router.message(FormStates.WAITING_FINISH_OR_ADD_BLOCK)
async def finish_or_add_block(message: Message, state: FSMContext):
    txt = message.text
    lang = await get_lang(state)

    if lang == "ru":
        if txt == "Завершить":
            await generate_and_send_pdf(message, state)
            await message.answer(
                "Документ сформирован. Что делаем?",
                reply_markup=after_generation_kb_ru
            )
            await state.set_state(FormStates.PDF_GENERATED)
        elif txt == "Добавить блок доп. информации":
            await message.answer("Добавьте новый блок информации или вернитесь к предыдущим шагам.")
        else:
            await message.answer("Кнопки: «Завершить» или «Добавить блок доп. информации».")
    else:
        if txt == "Finish":
            await generate_and_send_pdf(message, state)
            await message.answer(
                "Document generated. What's next?",
                reply_markup=after_generation_kb_en
            )
            await state.set_state(FormStates.PDF_GENERATED)
        elif txt == "Add extra info block":
            await message.answer("Add a new extra info block or go back to previous steps.")
        else:
            await message.answer("Buttons: 'Finish' or 'Add extra info block'.")


# --------------------------------------------------
# Генерация PDF и отправка
# --------------------------------------------------
async def generate_and_send_pdf(message: Message, state: FSMContext):
    data = await state.get_data()

    # Скачиваем 3x4
    photo_3x4_id = data.get("photo_3x4")
    if photo_3x4_id:
        local_path_34 = f"photos/3x4_{photo_3x4_id}.jpg"
        file_info = await bot.get_file(photo_3x4_id)
        await bot.download_file(file_info.file_path, local_path_34)
        data["photo_3x4"] = local_path_34
    else:
        data["photo_3x4"] = None

    # Скачиваем full
    photo_full_id = data.get("photo_full")
    if photo_full_id:
        local_path_full = f"photos/full_{photo_full_id}.jpg"
        file_info = await bot.get_file(photo_full_id)
        await bot.download_file(file_info.file_path, local_path_full)
        data["photo_full"] = local_path_full
    else:
        data["photo_full"] = None

    # Генерируем PDF
    pdf_buffer = await generate_pdf(data)
    pdf_buffer.seek(0)
    pdf_file = BufferedInputFile(file=pdf_buffer.read(), filename="Form.pdf")
    await message.answer_document(pdf_file)


# --------------------------------------------------
# Функция генерации PDF (ReportLab)
# --------------------------------------------------
async def generate_pdf(data: dict) -> BytesIO:
    buffer = BytesIO()
    doc = SimpleDocTemplate(
        buffer,
        pagesize=A4,
        leftMargin=2 * cm, rightMargin=2 * cm,
        topMargin=2 * cm, bottomMargin=2 * cm
    )

    styles = getSampleStyleSheet()
    style_normal = styles['Normal']
    style_normal.fontName = 'Montserrat'
    style_normal.fontSize = 10

    style_title = styles['Title']
    style_title.fontName = 'Montserrat'
    style_title.fontSize = 16

    style_heading = ParagraphStyle(
        'Heading',
        parent=style_normal,
        fontName='Montserrat',
        fontSize=12,
        spaceBefore=10,
        spaceAfter=5
    )

    lang = data.get("lang", "ru")
    elements = []

    # Фото 3×4
    p34 = data.get("photo_3x4")
    if p34 and os.path.isfile(p34):
        photo_3x4_img = Image(p34, width=3*cm, height=4*cm)
    else:
        photo_3x4_img = Paragraph("<i>No 3x4 photo</i>", style_normal)

    # Фото в полный рост
    pfull = data.get("photo_full")
    if pfull and os.path.isfile(pfull):
        photo_full_img = Image(pfull, width=4*cm, height=6*cm)
    else:
        photo_full_img = Paragraph("<i>No full-height photo</i>", style_normal)

    if lang == "ru":
        elements.append(Paragraph("Анкета", style_title))
        elements.append(Spacer(1, 0.5*cm))

        elements.append(Paragraph("Фото 3×4:", style_heading))
        elements.append(photo_3x4_img)
        elements.append(Spacer(1, 0.5*cm))

        elements.append(Paragraph("Фото в полный рост:", style_heading))
        elements.append(photo_full_img)
        elements.append(Spacer(1, 0.5*cm))

        # Основная инфа
        binfo = data.get("basic_info", {})
        elements.append(Paragraph("Основная информация:", style_heading))
        txt_bi = (
            f"Дата рождения: {binfo.get('birth_date','')}\n"
            f"Регистрация: {binfo.get('registration','')}\n"
            f"Проживание: {binfo.get('residence','')}\n"
            f"Рост: {binfo.get('height','')}\n"
            f"Вес: {binfo.get('weight','')}\n"
            f"Семейное положение: {binfo.get('marital','')}\n"
        )
        elements.append(Paragraph(txt_bi.replace("\n", "<br/>"), style_normal))

        # Опыт работы
        wlist = data.get("work_experience", [])
        if wlist:
            elements.append(Spacer(1, 0.5*cm))
            elements.append(Paragraph("Опыт работы:", style_heading))
            for i, wexp in enumerate(wlist, 1):
                wtxt = (
                    f"{i}. {wexp['employer']} / {wexp['city']} / {wexp['period']} / "
                    f"{wexp['position']} / {wexp['duties']}"
                )
                elements.append(Paragraph(wtxt, style_normal))

        # Военная служба
        ms = data.get("military_service")
        if ms:
            elements.append(Spacer(1, 0.5*cm))
            elements.append(Paragraph("Военная служба:", style_heading))
            ms_txt = (
                f"Подразделение: {ms['subdivision']}, "
                f"Период: {ms['period']}, "
                f"Звание: {ms['rank']}, "
                f"Примечания: {ms['notes']}"
            )
            elements.append(Paragraph(ms_txt, style_normal))

        # Образование
        edu_list = data.get("education", [])
        if edu_list:
            elements.append(Spacer(1, 0.5*cm))
            elements.append(Paragraph("Образование:", style_heading))
            for i, e in enumerate(edu_list, 1):
                etxt = (
                    f"{i}. {e['institution']} / {e['period']} / "
                    f"{e['type']} / {e['specialty']}"
                )
                elements.append(Paragraph(etxt, style_normal))

        # Доп.инфо
        add_info = data.get("additional_info", "")
        if add_info:
            elements.append(Spacer(1, 0.5*cm))
            elements.append(Paragraph("Дополнительная информация:", style_heading))
            elements.append(Paragraph(add_info, style_normal))

    else:
        # English
        elements.append(Paragraph("Form", style_title))
        elements.append(Spacer(1, 0.5*cm))

        elements.append(Paragraph("3×4 photo:", style_heading))
        elements.append(photo_3x4_img)
        elements.append(Spacer(1, 0.5*cm))

        elements.append(Paragraph("Full-height photo:", style_heading))
        elements.append(photo_full_img)
        elements.append(Spacer(1, 0.5*cm))

        # Basic info
        binfo = data.get("basic_info", {})
        elements.append(Paragraph("Basic info:", style_heading))
        txt_bi = (
            f"Birth date: {binfo.get('birth_date','')}\n"
            f"Registration: {binfo.get('registration','')}\n"
            f"Residence: {binfo.get('residence','')}\n"
            f"Height: {binfo.get('height','')}\n"
            f"Weight: {binfo.get('weight','')}\n"
            f"Marital status: {binfo.get('marital','')}\n"
        )
        elements.append(Paragraph(txt_bi.replace("\n", "<br/>"), style_normal))

        # Work experience
        wlist = data.get("work_experience", [])
        if wlist:
            elements.append(Spacer(1, 0.5*cm))
            elements.append(Paragraph("Work experience:", style_heading))
            for i, wexp in enumerate(wlist, 1):
                wtxt = (
                    f"{i}. {wexp['employer']} / {wexp['city']} / {wexp['period']} / "
                    f"{wexp['position']} / {wexp['duties']}"
                )
                elements.append(Paragraph(wtxt, style_normal))

        # Military
        ms = data.get("military_service")
        if ms:
            elements.append(Spacer(1, 0.5*cm))
            elements.append(Paragraph("Military service:", style_heading))
            ms_txt = (
                f"Subdivision: {ms['subdivision']}, "
                f"Period: {ms['period']}, "
                f"Rank: {ms['rank']}, "
                f"Notes: {ms['notes']}"
            )
            elements.append(Paragraph(ms_txt, style_normal))

        # Education
        edu_list = data.get("education", [])
        if edu_list:
            elements.append(Spacer(1, 0.5*cm))
            elements.append(Paragraph("Education:", style_heading))
            for i, e in enumerate(edu_list, 1):
                etxt = (
                    f"{i}. {e['institution']} / {e['period']} / "
                    f"{e['type']} / {e['specialty']}"
                )
                elements.append(Paragraph(etxt, style_normal))

        # Additional info
        add_info = data.get("additional_info", "")
        if add_info:
            elements.append(Spacer(1, 0.5*cm))
            elements.append(Paragraph("Additional info:", style_heading))
            elements.append(Paragraph(add_info, style_normal))

    doc.build(elements)
    buffer.seek(0)
    return buffer


# --------------------------------------------------
# После генерации PDF (PDF_GENERATED)
# --------------------------------------------------
@router.message(FormStates.PDF_GENERATED)
async def after_pdf_generated(message: Message, state: FSMContext):
    txt = message.text
    lang = await get_lang(state)

    if lang == "ru":
        if txt == "Внести исправления":
            await message.answer("Что хотите исправить?", reply_markup=edit_menu_kb_ru)
            await state.set_state(FormStates.WAITING_EDIT)
        elif txt == "Завершить":
            await message.answer("Документ сформирован окончательно. Завершаем.", reply_markup=ReplyKeyboardRemove())
            await state.clear()
        else:
            await message.answer("«Внести исправления» или «Завершить».")
    else:
        if txt == "Edit data":
            await message.answer("What do you want to edit?", reply_markup=edit_menu_kb_en)
            await state.set_state(FormStates.WAITING_EDIT)
        elif txt == "Finish":
            await message.answer("Document is finalized. Done.", reply_markup=ReplyKeyboardRemove())
            await state.clear()
        else:
            await message.answer("'Edit data' or 'Finish'.")


# --------------------------------------------------
# Редактирование (WAITING_EDIT)
# --------------------------------------------------
@router.message(FormStates.WAITING_EDIT)
async def edit_which_block(message: Message, state: FSMContext):
    """
    Выбираем блок, который хотим изменить.
    После того, как пользователь введёт новые данные,
    мы СРАЗУ генерируем PDF и возвращаемся к PDF_GENERATED
    (чтобы показать снова кнопки «Внести исправления» / «Завершить»).
    """
    txt = message.text
    lang = await get_lang(state)

    # Фотография 3x4
    if txt in ["Фотография 3x4", "Photo 3x4"]:
        if lang == "ru":
            t = "Пришлите новое фото 3×4."
        else:
            t = "Please send a new 3×4 photo."
        await message.answer(t, reply_markup=back_to_lang_kb)
        # Меняем state на WAITING_PHOTO_34,
        # но как только получим фото, СРАЗУ создаём PDF и возвращаемся в PDF_GENERATED
        await state.set_state(FormStates.WAITING_PHOTO_34)

    # Фото в полный рост
    elif txt in ["Фотография в полный рост", "Full height photo"]:
        if lang == "ru":
            t = "Пришлите новое фото в полный рост."
        else:
            t = "Please send a new full-height photo."
        await message.answer(t, reply_markup=back_to_lang_kb)
        await state.set_state(FormStates.WAITING_PHOTO_FULL)

    # Общая информация
    elif txt in ["Общая информация", "Basic info"]:
        if lang == "ru":
            t = (
                "Укажите (6 строк): дату рождения, регистрацию, проживание, рост, вес, семейное положение.\n"
                "Или «Пропустить»."
            )
        else:
            t = (
                "Enter (6 lines): birth date, registration, residence, height, weight, marital.\n"
                "Or 'Skip'."
            )
        await message.answer(t)
        await state.set_state(FormStates.WAITING_BASIC_INFO)

    # Опыт работы
    elif txt in ["Опыт работы", "Work experience"]:
        if lang == "ru":
            q = (
                "Опыт работы (5 строк) или «Пропустить»:\n"
                "1) Работодатель\n"
                "2) Город\n"
                "3) Период\n"
                "4) Должность\n"
                "5) Обязанности\n"
            )
        else:
            q = (
                "Work experience (5 lines) or 'Skip':\n"
                "1) Employer\n"
                "2) City\n"
                "3) Period\n"
                "4) Position\n"
                "5) Duties\n"
            )
        await message.answer(q)
        await state.set_state(FormStates.WAITING_WORK)

    # Военная служба
    elif txt in ["Военная служба", "Military service"]:
        await ask_military(message, state)

    # Образование
    elif txt in ["Образование", "Education"]:
        await ask_education(message, state)

    # Доп. инфа
    elif txt in ["Дополнительная информация", "Additional info"]:
        if lang == "ru":
            q = "Дополнительные данные (или «Пропустить»)."
        else:
            q = "Additional info (or 'Skip')."
        await message.answer(q)
        await state.set_state(FormStates.WAITING_ADDITIONAL_DATA)

    else:
        if lang == "ru":
            await message.answer("Неизвестный блок. Выберите из списка.")
        else:
            await message.answer("Unknown block. Choose from the list.")


# --------------------------------------------------
# ДОПОЛНИТЕЛЬНО: автоматический возврат в PDF_GENERATED
# --------------------------------------------------
# Чтобы после изменения конкретного блока сразу формировать PDF и возвращаться к "Внести/Завершить",
# мы перехватим некоторые состояния (например WAITING_PHOTO_34) заново,
# и после сохранения данных будем формировать PDF и показывать after_generation_kb_*.

# Пример: пользователь меняет фото 3×4.
@router.message(FormStates.WAITING_PHOTO_34, F.photo)
async def edit_photo_3x4_after(message: Message, state: FSMContext):
    """
    Если мы попали в WAITING_PHOTO_34 из режима редактирования,
    то после получения фото СРАЗУ формируем PDF и переходим в PDF_GENERATED.
    """
    file_id = message.photo[-1].file_id
    await state.update_data({"photo_3x4": file_id})

    # Генерируем новый PDF
    await generate_and_send_pdf(message, state)

    lang = await get_lang(state)
    if lang == "ru":
        await message.answer("Новое фото 3×4 учтено. Что делаем?", reply_markup=after_generation_kb_ru)
    else:
        await message.answer("New 3×4 photo updated. What's next?", reply_markup=after_generation_kb_en)

    await state.set_state(FormStates.PDF_GENERATED)

# Аналогично для WAITING_PHOTO_FULL
@router.message(FormStates.WAITING_PHOTO_FULL, F.photo)
async def edit_photo_full_after(message: Message, state: FSMContext):
    file_id = message.photo[-1].file_id
    await state.update_data({"photo_full": file_id})

    await generate_and_send_pdf(message, state)

    lang = await get_lang(state)
    if lang == "ru":
        await message.answer("Новое фото в полный рост учтено. Что делаем?", reply_markup=after_generation_kb_ru)
    else:
        await message.answer("New full-height photo updated. What's next?", reply_markup=after_generation_kb_en)

    await state.set_state(FormStates.PDF_GENERATED)


# То же самое, если пользователь меняет "Общую информацию", "Опыт работы" и т.д.
# Мы уже имеем хендлеры receive_basic_info, receive_work_exp, etc.
# Просто дополним их проверкой: если текущее состояние (или предыдущее) было WAITING_EDIT,
# тогда перегенерируем PDF сразу.

# Но проще всего — проверить текущее состояние.
# Ниже пример для basic_info (у нас один общий receive_basic_info).
# В конце добавим проверку: если пользователь уже «собирал» PDF раньше (т.е. state == WAITING_BASIC_INFO,
# но мы из WAITING_EDIT пришли), тогда PDF пересоздаётся.

# В текущем коде receive_basic_info уже описан.
# Дополним логику:
# (чтобы не дублировать, придётся чуть изменить)

@router.message(FormStates.WAITING_BASIC_INFO, F.text.in_(["Пропустить", "Skip"]))
async def skip_basic_info_during_edit(message: Message, state: FSMContext):
    """
    Если нажали "Пропустить" именно во время редактирования.
    """
    lang = await get_lang(state)
    if lang == "ru":
        bdict = {
            "birth_date": "Пропущено",
            "registration": "Пропущено",
            "residence": "Пропущено",
            "height": "Пропущено",
            "weight": "Пропущено",
            "marital": "Пропущено"
        }
    else:
        bdict = {
            "birth_date": "Skipped",
            "registration": "Skipped",
            "residence": "Skipped",
            "height": "Skipped",
            "weight": "Skipped",
            "marital": "Skipped"
        }
    await state.update_data({"basic_info": bdict})

    # Сразу формируем PDF и возвращаемся к PDF_GENERATED
    await generate_and_send_pdf(message, state)
    if lang == "ru":
        await message.answer("Основная информация пропущена (при редактировании). Что делаем?", reply_markup=after_generation_kb_ru)
    else:
        await message.answer("Basic info skipped (edit mode). What's next?", reply_markup=after_generation_kb_en)

    await state.set_state(FormStates.PDF_GENERATED)

# Теперь обработаем случай, когда пользователь вводит 6 строк.
@router.message(FormStates.WAITING_BASIC_INFO)
async def edit_basic_info_final(message: Message, state: FSMContext):
    """
    Пользователь ввёл 6 строк — обновим данные, пересоздадим PDF, вернёмся к PDF_GENERATED.
    """
    lines = message.text.split("\n")
    lang = await get_lang(state)

    if len(lines) < 6:
        if lang == "ru":
            await message.answer("Нужно 6 строк!")
        else:
            await message.answer("Need 6 lines!")
        return

    bdict = {
        "birth_date": lines[0].strip(),
        "registration": lines[1].strip(),
        "residence": lines[2].strip(),
        "height": lines[3].strip(),
        "weight": lines[4].strip(),
        "marital": lines[5].strip()
    }
    await state.update_data({"basic_info": bdict})

    await generate_and_send_pdf(message, state)
    if lang == "ru":
        await message.answer("Основная информация обновлена. Что делаем?", reply_markup=after_generation_kb_ru)
    else:
        await message.answer("Basic info updated. What's next?", reply_markup=after_generation_kb_en)

    await state.set_state(FormStates.PDF_GENERATED)


# Аналогичную логику вставим для опыта работы, военной службы, образования, доп.инфы:
# - Как только пользователь ввёл новые данные — тут же формируем PDF и возвр. state = PDF_GENERATED.
# Ниже — для примера опыта работы (WAITING_WORK).

@router.message(FormStates.WAITING_WORK, F.text.in_(["Пропустить", "Skip"]))
async def skip_work_during_edit(message: Message, state: FSMContext):
    """
    При редактировании блока "Опыт работы" нажали «Пропустить».
    Очистим (или не трогаем) work_experience,
    потом сразу генерим PDF и вернёмся к PDF_GENERATED.
    """
    data_ = await state.get_data()
    # Можно либо обнулить опыт, либо оставить как есть.
    # Допустим, обнулим.
    data_["work_experience"] = []
    await state.update_data(data_)

    lang = await get_lang(state)
    await generate_and_send_pdf(message, state)
    if lang == "ru":
        await message.answer("Опыт работы стёрт (пропущен). Что дальше?", reply_markup=after_generation_kb_ru)
    else:
        await message.answer("Work experience cleared. What's next?", reply_markup=after_generation_kb_en)

    await state.set_state(FormStates.PDF_GENERATED)

@router.message(FormStates.WAITING_WORK)
async def edit_work_final(message: Message, state: FSMContext):
    """
    Ввод 5 строк. Сразу обновляем, генерим PDF, возвращаем PDF_GENERATED.
    """
    lines = message.text.split("\n")
    lang = await get_lang(state)
    if len(lines) < 5:
        if lang == "ru":
            await message.answer("Нужно 5 строк!")
        else:
            await message.answer("Need 5 lines!")
        return

    data_ = await state.get_data()
    wlist = data_.get("work_experience", [])
    wdict = {
        "employer": lines[0].strip(),
        "city": lines[1].strip(),
        "period": lines[2].strip(),
        "position": lines[3].strip(),
        "duties": lines[4].strip()
    }
    wlist.append(wdict)
    data_["work_experience"] = wlist
    await state.update_data(data_)

    await generate_and_send_pdf(message, state)
    if lang == "ru":
        await message.answer("Опыт работы обновлён. Что дальше?", reply_markup=after_generation_kb_ru)
    else:
        await message.answer("Work experience updated. What's next?", reply_markup=after_generation_kb_en)

    await state.set_state(FormStates.PDF_GENERATED)

# Аналогично для WAITING_MILITARY_DATA, WAITING_EDUCATION_DATA, WAITING_ADDITIONAL_DATA —
# вы копируете/вставляете этот паттерн:
# 1) Если "Пропустить" / "Skip", то обнуляем или оставляем поле.
# 2) Если ввели нужное кол-во строк, обновляем state.
# 3) Генерируем PDF, возвращаемся к PDF_GENERATED.


# --------------------------------------------------
# Запуск бота
# --------------------------------------------------
dp.include_router(router)

async def main():
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())