import os
import asyncio
from io import BytesIO

from dotenv import load_dotenv
from aiogram import Bot, Dispatcher, Router, F
from aiogram.types import (
    Message, PhotoSize,
    ReplyKeyboardMarkup, KeyboardButton,
    ReplyKeyboardRemove, BufferedInputFile
)
from aiogram.filters import CommandStart
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import StatesGroup, State
from aiogram.fsm.storage.memory import MemoryStorage

# REPORTLAB + Montserrat
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import cm
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle

load_dotenv()
BOT_TOKEN = os.getenv("BOT_TOKEN")

bot = Bot(token=BOT_TOKEN)
dp = Dispatcher(storage=MemoryStorage())
router = Router()

pdfmetrics.registerFont(TTFont('Montserrat', 'fonts/Montserrat-Regular.ttf'))
os.makedirs("photos", exist_ok=True)

# Главное меню языка
choose_language_kb = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="Создать анкету на русском")],
        [KeyboardButton(text="Create form in English")],
    ],
    resize_keyboard=True
)

back_to_lang_kb = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="Назад"), KeyboardButton(text="Back")]
    ],
    resize_keyboard=True
)

add_or_finish_kb_ru = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="Добавить данные")],
        [KeyboardButton(text="Завершить создание документа")],
    ],
    resize_keyboard=True
)

add_or_finish_kb_en = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="Add data")],
        [KeyboardButton(text="Finish document")],
    ],
    resize_keyboard=True
)

after_generation_kb_ru = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="Внести исправления")],
        [KeyboardButton(text="Завершить")],
    ],
    resize_keyboard=True
)

after_generation_kb_en = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="Edit data")],
        [KeyboardButton(text="Finish")],
    ],
    resize_keyboard=True
)

class FormStates(StatesGroup):
    CHOOSE_LANG = State()
    WAITING_PHOTO_34 = State()
    WAITING_PHOTO_FULL = State()
    WAITING_ADD_OR_FINISH = State()

    # Ниже новые состояния
    WAITING_BASIC_INFO = State()
    # (по аналогии можно сделать WAITING_WORK, WAITING_EDUCATION, etc.)

    PDF_GENERATED = State()
    WAITING_EDIT = State()

async def get_lang(state: FSMContext) -> str:
    data = await state.get_data()
    return data.get("lang", "ru")

@router.message(CommandStart())
async def cmd_start(message: Message, state: FSMContext):
    await state.clear()
    text = (
        "Привет! Это бот для создания анкет.\n"
        "Выберите язык анкеты:\n\n"
        "Hello! This is a bot for creating forms.\n"
        "Choose language:"
    )
    await message.answer(text, reply_markup=choose_language_kb)
    await state.set_state(FormStates.CHOOSE_LANG)

@router.message(FormStates.CHOOSE_LANG, F.text == "Создать анкету на русском")
async def select_russian(message: Message, state: FSMContext):
    await state.update_data({
        "lang": "ru",
        "photo_3x4": None,
        "photo_full": None,
        "basic_info": {}
    })
    await message.answer(
        "Вы выбрали анкету на русском.\n"
        "Пожалуйста, отправьте фотографию (3×4).",
        reply_markup=back_to_lang_kb
    )
    await state.set_state(FormStates.WAITING_PHOTO_34)

@router.message(FormStates.CHOOSE_LANG, F.text == "Create form in English")
async def select_english(message: Message, state: FSMContext):
    await state.update_data({
        "lang": "en",
        "photo_3x4": None,
        "photo_full": None,
        "basic_info": {}
    })
    await message.answer(
        "You have chosen to fill the form in English.\n"
        "Please send a 3/4 photo (passport style).",
        reply_markup=back_to_lang_kb
    )
    await state.set_state(FormStates.WAITING_PHOTO_34)

@router.message(FormStates.CHOOSE_LANG)
async def unknown_lang_choice(message: Message):
    await message.answer("Пожалуйста, используйте кнопки / Please use the buttons.")

@router.message(FormStates.WAITING_PHOTO_34, F.text.in_(["Назад", "Back"]))
async def photo34_back(message: Message, state: FSMContext):
    await cmd_start(message, state)

@router.message(FormStates.WAITING_PHOTO_34, F.photo)
async def receive_photo_34(message: Message, state: FSMContext):
    user_id = message.from_user.id
    lang = await get_lang(state)
    file_id = message.photo[-1].file_id

    file_info = await bot.get_file(file_id)
    downloaded_file = await bot.download_file(file_info.file_path)

    local_path = f"photos/photo_34_{user_id}.jpg"
    with open(local_path, "wb") as f:
        f.write(downloaded_file.getvalue())

    await state.update_data({"photo_3x4": local_path})

    if lang == "ru":
        txt = "Фото 3×4 получено!\nТеперь отправьте фотографию сотрудника в полный рост."
    else:
        txt = "3×4 photo received!\nNow send the full-height photo."

    await message.answer(txt, reply_markup=back_to_lang_kb)
    await state.set_state(FormStates.WAITING_PHOTO_FULL)

@router.message(FormStates.WAITING_PHOTO_34)
async def not_a_photo_34(message: Message, state: FSMContext):
    lang = await get_lang(state)
    if lang == "ru":
        await message.answer("Пожалуйста, пришлите фото (не текст).")
    else:
        await message.answer("Please send a photo, not text.")

@router.message(FormStates.WAITING_PHOTO_FULL, F.text.in_(["Назад", "Back"]))
async def photo_full_back(message: Message, state: FSMContext):
    if (await get_lang(state))=="ru":
        await select_russian(message, state)
    else:
        await select_english(message, state)

@router.message(FormStates.WAITING_PHOTO_FULL, F.photo)
async def receive_photo_full(message: Message, state: FSMContext):
    user_id = message.from_user.id
    lang = await get_lang(state)

    file_id = message.photo[-1].file_id
    file_info = await bot.get_file(file_id)
    downloaded_file = await bot.download_file(file_info.file_path)

    local_path = f"photos/photo_full_{user_id}.jpg"
    with open(local_path, "wb") as f:
        f.write(downloaded_file.getvalue())

    await state.update_data({"photo_full": local_path})

    if lang == "ru":
        txt = (
            "Фото в полный рост получено.\n"
            "Теперь вы можете добавить информацию или сразу завершить документ."
        )
        kb = add_or_finish_kb_ru
    else:
        txt = (
            "Full-height photo received.\n"
            "Now you can add info or finish the document."
        )
        kb = add_or_finish_kb_en

    await message.answer(txt, reply_markup=kb)
    await state.set_state(FormStates.WAITING_ADD_OR_FINISH)

@router.message(FormStates.WAITING_PHOTO_FULL)
async def not_a_photo_full(message: Message, state: FSMContext):
    lang = await get_lang(state)
    if lang == "ru":
        await message.answer("Пожалуйста, пришлите фото (не текст).")
    else:
        await message.answer("Please send a photo, not text.")

# ------------ Обработка кнопок "Добавить данные" / "Завершить" -------------
@router.message(FormStates.WAITING_ADD_OR_FINISH, F.text == "Добавить данные")
async def add_data_ru(message: Message, state: FSMContext):
    """Пользователь нажал «Добавить данные» (рус). Спрашиваем 6 строк общей инфы."""
    await message.answer(
        "Вы выбрали: добавить данные (РУССКИЙ).\n"
        "Пожалуйста, введите 6 строк (дата рождения, место регистрации, место проживания, рост, вес, семейное положение):\n"
        "Пример:\n01.01.2000\nМосква\nМосква\n180\n80\nЖенат\n\n"
        "Или напишите «пропустить», если не нужно."
    )
    await state.set_state(FormStates.WAITING_BASIC_INFO)

@router.message(FormStates.WAITING_ADD_OR_FINISH, F.text == "Завершить создание документа")
async def finish_document_ru(message: Message, state: FSMContext):
    """Пользователь нажал «Завершить создание документа» (рус). Генерируем PDF."""
    await generate_and_send_pdf(message, state)
    await state.set_state(FormStates.PDF_GENERATED)

@router.message(FormStates.WAITING_ADD_OR_FINISH, F.text == "Add data")
async def add_data_en(message: Message, state: FSMContext):
    """User clicked 'Add data' (eng)"""
    await message.answer(
        "You chose: Add data (EN).\n"
        "Please enter 6 lines (birth date, registration place, residence, height, weight, marital status).\n"
        "Or type 'skip' if not needed."
    )
    await state.set_state(FormStates.WAITING_BASIC_INFO)

@router.message(FormStates.WAITING_ADD_OR_FINISH, F.text == "Finish document")
async def finish_document_en(message: Message, state: FSMContext):
    """User clicked 'Finish document' (eng)."""
    await generate_and_send_pdf(message, state)
    await state.set_state(FormStates.PDF_GENERATED)

@router.message(FormStates.WAITING_ADD_OR_FINISH)
async def unknown_add_finish(message: Message, state: FSMContext):
    lang = await get_lang(state)
    if lang=="ru":
        await message.answer("Пожалуйста, используйте кнопки: «Добавить данные» или «Завершить создание документа».")
    else:
        await message.answer("Please use the buttons: 'Add data' or 'Finish document'.")

# ------------ Теперь обрабатываем ввод (6 строк) -------------
@router.message(FormStates.WAITING_BASIC_INFO, F.text.lower() == "пропустить")
async def skip_basic_info_ru(message: Message, state: FSMContext):
    """Если пользователь вводит «пропустить» (рус)"""
    data = await state.get_data()
    data["basic_info"] = {
        "birth_date": "Пропущено",
        "registration": "Пропущено",
        "residence": "Пропущено",
        "height": "Пропущено",
        "weight": "Пропущено",
        "marital": "Пропущено"
    }
    await state.update_data(data)
    # Сразу генерируем PDF или переходим к другим блокам — по вашему желанию
    await generate_and_send_pdf(message, state)
    await state.set_state(FormStates.PDF_GENERATED)

@router.message(FormStates.WAITING_BASIC_INFO, F.text.lower() == "skip")
async def skip_basic_info_en(message: Message, state: FSMContext):
    """Если пользователь вводит 'skip' (англ)"""
    data = await state.get_data()
    data["basic_info"] = {
        "birth_date": "Skipped",
        "registration": "Skipped",
        "residence": "Skipped",
        "height": "Skipped",
        "weight": "Skipped",
        "marital": "Skipped"
    }
    await state.update_data(data)
    await generate_and_send_pdf(message, state)
    await state.set_state(FormStates.PDF_GENERATED)

@router.message(FormStates.WAITING_BASIC_INFO)
async def receive_basic_info(message: Message, state: FSMContext):
    """Получаем 6 строк (дата, регистрация, проживание, рост, вес, семейное положение)."""
    lines = message.text.split("\n")
    if len(lines) < 6:
        await message.answer("Нужно 6 строк (или пропустить/skip)!")
        return

    data = await state.get_data()
    data["basic_info"] = {
        "birth_date": lines[0].strip(),
        "registration": lines[1].strip(),
        "residence": lines[2].strip(),
        "height": lines[3].strip(),
        "weight": lines[4].strip(),
        "marital": lines[5].strip()
    }
    await state.update_data(data)

    # Допустим, после заполнения общей инфы сразу генерируем PDF
    await generate_and_send_pdf(message, state)
    await state.set_state(FormStates.PDF_GENERATED)

# ---------------------------
# Генерация PDF
# ---------------------------
async def generate_and_send_pdf(message: Message, state: FSMContext):
    data = await state.get_data()
    pdf_buffer = await generate_pdf(data)
    pdf_buffer.seek(0)
    pdf_bytes = pdf_buffer.read()

    lang = data.get("lang","ru")
    if lang=="ru":
        doc_caption = "Готовый документ (PDF)."
        follow_text = "Хотите внести исправления или «Завершить»?"
        after_kb = after_generation_kb_ru
    else:
        doc_caption = "Here is your PDF."
        follow_text = "Do you want to edit data or Finish?"
        after_kb = after_generation_kb_en

    await message.answer_document(
        document=BufferedInputFile(pdf_bytes, filename="Anketa.pdf"),
        caption=doc_caption
    )
    await message.answer(follow_text, reply_markup=after_kb)

@router.message(FormStates.PDF_GENERATED, F.text.in_(["Внести исправления", "Edit data"]))
async def edit_document(message: Message, state: FSMContext):
    lang = await get_lang(state)
    if lang=="ru":
        await message.answer("Что хотите исправить? (Демо)", reply_markup=ReplyKeyboardRemove())
        # Тут можно вернуть меню редактирования
    else:
        await message.answer("What do you want to edit? (demo)", reply_markup=ReplyKeyboardRemove())
    # Тут переход в FSM для редактирования...

@router.message(FormStates.PDF_GENERATED, F.text.in_(["Завершить", "Finish"]))
async def finalize_doc(message: Message, state: FSMContext):
    lang = await get_lang(state)
    if lang=="ru":
        text = "Документ сформирован окончательно. Завершаем."
    else:
        text = "Document is finalized. Done."
    await message.answer(text, reply_markup=ReplyKeyboardRemove())
    await state.clear()

@router.message(FormStates.PDF_GENERATED)
async def unknown_after_pdf(message: Message, state: FSMContext):
    lang = await get_lang(state)
    if lang=="ru":
        await message.answer("«Внести исправления» или «Завершить».")
    else:
        await message.answer("'Edit data' or 'Finish'.")

# ---------------------------
# Функция generate_pdf
# ---------------------------
async def generate_pdf(data: dict):
    buffer = BytesIO()

    doc = SimpleDocTemplate(
        buffer, pagesize=A4,
        leftMargin=2*cm, rightMargin=2*cm,
        topMargin=2*cm, bottomMargin=2*cm
    )

    styles = getSampleStyleSheet()
    style_normal = styles['Normal']
    style_normal.fontName = 'Montserrat'
    style_normal.fontSize = 10

    style_title = styles['Title']
    style_title.fontName = 'Montserrat'
    style_title.fontSize = 16

    style_heading = ParagraphStyle(
        'Heading',
        parent=style_normal,
        fontName='Montserrat',
        fontSize=12,
        spaceBefore=10,
        spaceAfter=5
    )

    lang = data.get("lang","ru")
    elements = []

    # Фото 3×4
    photo_3x4_path = data.get("photo_3x4")
    if photo_3x4_path and os.path.isfile(photo_3x4_path):
        img_34 = Image(photo_3x4_path, width=3*cm, height=4*cm)
    else:
        img_34 = Paragraph("<i>No 3×4 photo</i>", style_normal)

    # Фото полный рост
    photo_full_path = data.get("photo_full")
    if photo_full_path and os.path.isfile(photo_full_path):
        img_full = Image(photo_full_path, width=4*cm, height=6*cm)
    else:
        img_full = Paragraph("<i>No full-height photo</i>", style_normal)

    # Добавим заголовок
    if lang == "ru":
        elements.append(Paragraph("<b>Анкета</b>", style_title))
        elements.append(Spacer(1, 0.5*cm))
        elements.append(Paragraph("Фото 3×4:", style_heading))
        elements.append(img_34)
        elements.append(Spacer(1, 0.5*cm))
        elements.append(Paragraph("Фото в полный рост:", style_heading))
        elements.append(img_full)
        elements.append(Spacer(1, 1*cm))

        # Вставим табличку с общей инфой
        binfo = data.get("basic_info", {})
        table_data = [
            ["Дата рождения:", binfo.get("birth_date","")],
            ["Регистрация:", binfo.get("registration","")],
            ["Проживание:", binfo.get("residence","")],
            ["Рост, Вес:", f"{binfo.get('height','')} / {binfo.get('weight','')}"],
            ["Семейное положение:", binfo.get("marital","")],
        ]
        t = Table(table_data, colWidths=[5*cm, 8*cm])
        t.setStyle(TableStyle([
            ('FONT', (0,0), (-1,-1), 'Montserrat', 10),
            ('VALIGN',(0,0),(-1,-1),'TOP'),
        ]))
        elements.append(Paragraph("Основная информация:", style_heading))
        elements.append(t)

    else:
        elements.append(Paragraph("<b>Form</b>", style_title))
        elements.append(Spacer(1, 0.5*cm))
        elements.append(Paragraph("3×4 photo:", style_heading))
        elements.append(img_34)
        elements.append(Spacer(1, 0.5*cm))
        elements.append(Paragraph("Full-height photo:", style_heading))
        elements.append(img_full)
        elements.append(Spacer(1, 1*cm))

        # Table with basic info
        binfo = data.get("basic_info", {})
        table_data = [
            ["Birth date:", binfo.get("birth_date","")],
            ["Registration:", binfo.get("registration","")],
            ["Residence:", binfo.get("residence","")],
            ["Height / Weight:", f"{binfo.get('height','')}/{binfo.get('weight','')}"],
            ["Marital status:", binfo.get("marital","")],
        ]
        t = Table(table_data, colWidths=[5*cm, 8*cm])
        t.setStyle(TableStyle([
            ('FONT', (0,0), (-1,-1), 'Montserrat', 10),
            ('VALIGN',(0,0),(-1,-1),'TOP'),
        ]))
        elements.append(Paragraph("Basic info:", style_heading))
        elements.append(t)

    doc.build(elements)
    buffer.seek(0)
    return buffer

dp.include_router(router)

async def main():
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())