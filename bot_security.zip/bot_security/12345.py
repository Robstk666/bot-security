import os
import asyncio
from io import BytesIO

from dotenv import load_dotenv
from aiogram import Bot, Dispatcher, Router, F
from aiogram.types import (
    Message, PhotoSize,
    ReplyKeyboardMarkup, KeyboardButton,
    ReplyKeyboardRemove, BufferedInputFile
)
from aiogram.filters import CommandStart
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import StatesGroup, State
from aiogram.fsm.storage.memory import MemoryStorage

# ReportLab + Montserrat
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import cm
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle

# 1) Загружаем токен из .env
load_dotenv()
BOT_TOKEN = os.getenv("BOT_TOKEN")

# Настраиваем бота и диспетчер
bot = Bot(token=BOT_TOKEN)
dp = Dispatcher(storage=MemoryStorage())
router = Router()

# Регистрируем шрифт Montserrat (положите "Montserrat-Regular.ttf" в папку fonts/)
os.makedirs("fonts", exist_ok=True)
pdfmetrics.registerFont(TTFont('Montserrat', 'fonts/Montserrat-Regular.ttf'))

# Папка для сохранения фото
os.makedirs("photos", exist_ok=True)

# ---------------------------
# Клавиатуры
# ---------------------------

# Главное меню языка (только русский, но оставим "Создать анкету на английском" как демо)
choose_language_kb = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="Создать анкету на русском")],
        [KeyboardButton(text="Создать анкету на английском")],
    ],
    resize_keyboard=True
)

# Кнопка "Назад"
back_to_lang_kb = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="Назад")],
    ],
    resize_keyboard=True
)

# Меню "Добавить / Завершить"
add_or_finish_kb = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="Добавить данные")],
        [KeyboardButton(text="Завершить создание документа")],
    ],
    resize_keyboard=True
)

# Меню после генерации PDF
after_generation_kb = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="Внести исправления")],
        [KeyboardButton(text="Завершить")],
    ],
    resize_keyboard=True
)

# Меню «Добавить ещё опыт работы / Перейти к следующему шагу»
work_or_next_kb = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="Добавить опыт работы")],
        [KeyboardButton(text="Перейти к следующему шагу")],
    ],
    resize_keyboard=True
)

# Военная служба
service_or_next_kb = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="Добавить опыт службы")],
        [KeyboardButton(text="Перейти к следующему шагу")],
    ],
    resize_keyboard=True
)

# Образование
edu_or_next_kb = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="Добавить образование")],
        [KeyboardButton(text="Перейти к следующему шагу")],
    ],
    resize_keyboard=True
)

# Меню «Завершить» / «Добавить блок доп. информации»
finish_or_add_block_kb = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="Добавить блок доп. информации")],
        [KeyboardButton(text="Завершить")],
    ],
    resize_keyboard=True
)

# Меню для редактирования
edit_menu_kb = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="Фотография 3x4"), KeyboardButton(text="Фотография в полный рост")],
        [KeyboardButton(text="Общая информация"), KeyboardButton(text="Опыт работы")],
        [KeyboardButton(text="Военная служба"), KeyboardButton(text="Образование")],
        [KeyboardButton(text="Дополнительная информация")],
    ],
    resize_keyboard=True
)

# ---------------------------
# Состояния FSM
# ---------------------------
class FormStates(StatesGroup):
    CHOOSE_LANG = State()
    WAITING_PHOTO_34 = State()
    WAITING_PHOTO_FULL = State()
    WAITING_ADD_OR_FINISH = State()

    WAITING_BASIC_INFO = State()
    WAITING_WORK = State()
    WAITING_WORK_CHOICE = State()

    WAITING_MILITARY_DATA = State()
    WAITING_MILITARY_CHOICE = State()

    WAITING_EDUCATION_DATA = State()
    WAITING_EDUCATION_CHOICE = State()

    WAITING_ADDITIONAL_DATA = State()
    WAITING_FINISH_OR_ADD_BLOCK = State()

    PDF_GENERATED = State()
    WAITING_EDIT = State()

# ---------------------------
# /start
# ---------------------------
@router.message(CommandStart())
async def cmd_start(message: Message, state: FSMContext):
    """
    Показываем выбор языка (демо: русский/англ). Очищаем state.
    """
    await state.clear()
    await message.answer(
        "Привет! Это бот для создания анкет.\nВыберите язык анкеты:",
        reply_markup=choose_language_kb
    )
    await state.set_state(FormStates.CHOOSE_LANG)

# ---------------------------
# Выбор языка
# ---------------------------
@router.message(FormStates.CHOOSE_LANG, F.text == "Создать анкету на русском")
async def form_russian(message: Message, state: FSMContext):
    """
    Запускаем логику русского сценария.
    """
    await state.update_data({
        "lang": "ru",
        "photo_3x4": None,
        "photo_full": None,
        "basic_info": {},
        "work_experience": [],
        "military_service": None,
        "education": [],
        "additional_info": None
    })
    # Просим фото 3x4
    await message.answer(
        "Вы выбрали анкету на русском.\n"
        "Пожалуйста, отправьте фотографию (как на паспорт) — 3×4.",
        reply_markup=back_to_lang_kb
    )
    await state.set_state(FormStates.WAITING_PHOTO_34)

@router.message(FormStates.CHOOSE_LANG, F.text == "Создать анкету на английском")
async def form_english(message: Message, state: FSMContext):
    """
    Тут мог бы быть английский сценарий,
    но по ТЗ мы делаем логика только русская — оставим заглушку.
    """
    await state.clear()
    await message.answer("Английский сценарий не реализован. (Demo)")

@router.message(FormStates.CHOOSE_LANG)
async def unknown_lang_choice(message: Message):
    await message.answer("Пожалуйста, используйте кнопки для выбора языка.")

# ---------------------------
# Фото 3×4
# ---------------------------
@router.message(FormStates.WAITING_PHOTO_34, F.text == "Назад")
async def photo34_back(message: Message, state: FSMContext):
    await cmd_start(message, state)

@router.message(FormStates.WAITING_PHOTO_34, F.photo)
async def receive_photo_34(message: Message, state: FSMContext):
    """
    Сохраняем фото 3×4 (физически на диск).
    """
    user_id = message.from_user.id
    file_id = message.photo[-1].file_id

    # Скачиваем через bot.get_file + bot.download_file
    file_info = await bot.get_file(file_id)
    downloaded_file = await bot.download_file(file_info.file_path)

    os.makedirs("photos", exist_ok=True)
    local_path = f"photos/photo_3x4_{user_id}.jpg"
    with open(local_path, "wb") as f:
        f.write(downloaded_file.getvalue())

    await state.update_data({"photo_3x4": local_path})

    await message.answer(
        "Фото 3×4 получено!\nТеперь отправьте фотографию сотрудника в полный рост.",
        reply_markup=back_to_lang_kb
    )
    await state.set_state(FormStates.WAITING_PHOTO_FULL)

@router.message(FormStates.WAITING_PHOTO_34)
async def not_a_photo_34(message: Message):
    await message.answer("Пожалуйста, пришлите фото (не текст).")

# ---------------------------
# Фото в полный рост
# ---------------------------
@router.message(FormStates.WAITING_PHOTO_FULL, F.text == "Назад")
async def photo_full_back(message: Message, state: FSMContext):
    await form_russian(message, state)

@router.message(FormStates.WAITING_PHOTO_FULL, F.photo)
async def receive_photo_full(message: Message, state: FSMContext):
    user_id = message.from_user.id
    file_id = message.photo[-1].file_id

    file_info = await bot.get_file(file_id)
    downloaded_file = await bot.download_file(file_info.file_path)

    local_path = f"photos/photo_full_{user_id}.jpg"
    with open(local_path, "wb") as f:
        f.write(downloaded_file.getvalue())

    await state.update_data({"photo_full": local_path})

    await message.answer(
        "Фото в полный рост получено.\n"
        "Теперь вы можете добавить информацию или сразу завершить документ.",
        reply_markup=add_or_finish_kb
    )
    await state.set_state(FormStates.WAITING_ADD_OR_FINISH)

@router.message(FormStates.WAITING_PHOTO_FULL)
async def not_a_photo_full(message: Message):
    await message.answer("Пожалуйста, пришлите фото (не текст).")

# ---------------------------
# Добавить данные или завершить документ
# ---------------------------
@router.message(FormStates.WAITING_ADD_OR_FINISH, F.text == "Добавить данные")
async def add_data_start(message: Message, state: FSMContext):
    """
    Начинаем собирать основную инфу (дата рождения, место регистрации,
    место проживания, рост, вес, семейное положение)
    """
    await message.answer(
        "Пожалуйста, введите 6 строк (дата рождения, место регистрации, место проживания, рост, вес, семейное положение):\n\n"
        "Пример:\n01.01.1990\nМосква\nМосква\n180\n80\nЖенат\n\n"
        "Или напишите «Пропустить», если не хотите указывать.",
        reply_markup=ReplyKeyboardMarkup(
            keyboard=[[KeyboardButton(text="Пропустить")]],
            resize_keyboard=True
        )
    )
    await state.set_state(FormStates.WAITING_BASIC_INFO)

@router.message(FormStates.WAITING_ADD_OR_FINISH, F.text == "Завершить создание документа")
async def finish_early(message: Message, state: FSMContext):
    # Генерируем PDF сразу (без данных)
    await generate_and_send_pdf(message, state)
    await state.set_state(FormStates.PDF_GENERATED)

@router.message(FormStates.WAITING_ADD_OR_FINISH)
async def unknown_add_or_finish(message: Message):
    await message.answer("Пожалуйста, используйте кнопки: «Добавить данные» или «Завершить создание документа».")

# ---------------------------
# Получаем / пропускаем основную инфу
# ---------------------------
@router.message(FormStates.WAITING_BASIC_INFO, F.text == "Пропустить")
async def skip_basic_info(message: Message, state: FSMContext):
    # Заполняем всё «Пропущено» и идём дальше (опыт работы)
    await state.update_data({"basic_info": {
        "birth_date": "Пропущено",
        "registration": "Пропущено",
        "residence": "Пропущено",
        "height": "Пропущено",
        "weight": "Пропущено",
        "marital": "Пропущено"
    }})
    await ask_for_work(message, state)

@router.message(FormStates.WAITING_BASIC_INFO)
async def receive_basic_info(message: Message, state: FSMContext):
    """
    Ожидаем 6 строк: Дата рождения, место регистрации, место проживания, рост, вес, семейное положение
    """
    lines = message.text.split("\n")
    if len(lines) < 6:
        await message.answer("Нужно 6 строк!")
        return
    bdict = {
        "birth_date": lines[0].strip(),
        "registration": lines[1].strip(),
        "residence": lines[2].strip(),
        "height": lines[3].strip(),
        "weight": lines[4].strip(),
        "marital": lines[5].strip()
    }
    await state.update_data({"basic_info": bdict})
    await ask_for_work(message, state)

# ---------------------------
# Опыт работы
# ---------------------------
async def ask_for_work(message: Message, state: FSMContext):
    await message.answer(
        "Пожалуйста, укажите данные об опыте работы (5 строк, обязательно перенос строк!):\n\n"
        "1) Наименование работодателя\n"
        "2) Город места работы\n"
        "3) Период (например: 2010 2015)\n"
        "4) Должность\n"
        "5) Обязанности\n\n"
        "Или нажмите «Пропустить» чтобы перейти к следующему шагу.",
        reply_markup=ReplyKeyboardMarkup(
            keyboard=[[KeyboardButton(text="Пропустить")]],
            resize_keyboard=True
        )
    )
    await state.set_state(FormStates.WAITING_WORK)

@router.message(FormStates.WAITING_WORK, F.text == "Пропустить")
async def skip_work(message: Message, state: FSMContext):
    await go_next_work(message, state)

@router.message(FormStates.WAITING_WORK)
async def receive_work(message: Message, state: FSMContext):
    lines = message.text.split("\n")
    if len(lines) < 5:
        await message.answer("Нужно 5 строк!")
        return
    data_ = await state.get_data()
    wlist = data_.get("work_experience", [])
    wlist.append({
        "employer": lines[0].strip(),
        "city": lines[1].strip(),
        "period": lines[2].strip(),
        "position": lines[3].strip(),
        "duties": lines[4].strip()
    })
    await state.update_data({"work_experience": wlist})

    await message.answer(
        "Опыт работы добавлен. «Добавить опыт работы» или «Перейти к следующему шагу»?",
        reply_markup=work_or_next_kb
    )
    await state.set_state(FormStates.WAITING_WORK_CHOICE)

@router.message(FormStates.WAITING_WORK_CHOICE, F.text == "Добавить опыт работы")
async def add_more_work(message: Message, state: FSMContext):
    await message.answer(
        "Введите ещё 5 строк или «Пропустить».",
        reply_markup=ReplyKeyboardMarkup(
            keyboard=[[KeyboardButton(text="Пропустить")]],
            resize_keyboard=True
        )
    )
    await state.set_state(FormStates.WAITING_WORK)

@router.message(FormStates.WAITING_WORK_CHOICE, F.text == "Перейти к следующему шагу")
async def go_next_work(message: Message, state: FSMContext):
    # Военная служба
    await message.answer(
        "Пожалуйста, укажите данные о военной службе или нажмите «Пропустить».\n\n"
        "Формат (4 строки):\n"
        "1) Наименование подразделения\n"
        "2) Год начала (пробел) Год конца службы\n"
        "3) Звание\n"
        "4) Обязанности/Примечания\n",
        reply_markup=ReplyKeyboardMarkup(
            keyboard=[[KeyboardButton(text="Пропустить")]],
            resize_keyboard=True
        )
    )
    await state.set_state(FormStates.WAITING_MILITARY_DATA)

@router.message(FormStates.WAITING_WORK_CHOICE)
async def unknown_work_choice(message: Message):
    await message.answer("Кнопки: «Добавить опыт работы» или «Перейти к следующему шагу».")

# ---------------------------
# Военная служба
# ---------------------------
@router.message(FormStates.WAITING_MILITARY_DATA, F.text == "Пропустить")
async def skip_military(message: Message, state: FSMContext):
    await state.update_data({"military_service": None})
    await ask_for_education(message, state)

@router.message(FormStates.WAITING_MILITARY_DATA)
async def receive_military(message: Message, state: FSMContext):
    lines = message.text.split("\n")
    if len(lines) < 4:
        await message.answer("Нужно 4 строки!")
        return
    ms_dict = {
        "subdivision": lines[0].strip(),
        "period": lines[1].strip(),
        "rank": lines[2].strip(),
        "notes": lines[3].strip()
    }
    await state.update_data({"military_service": ms_dict})

    await message.answer(
        "Военная служба добавлена. «Добавить опыт службы» или «Перейти к следующему шагу»?",
        reply_markup=service_or_next_kb
    )
    await state.set_state(FormStates.WAITING_MILITARY_CHOICE)

@router.message(FormStates.WAITING_MILITARY_CHOICE, F.text == "Добавить опыт службы")
async def add_more_military(message: Message, state: FSMContext):
    await message.answer(
        "Введите ещё 4 строки или «Пропустить».",
        reply_markup=ReplyKeyboardMarkup(
            keyboard=[[KeyboardButton(text="Пропустить")]],
            resize_keyboard=True
        )
    )
    await state.set_state(FormStates.WAITING_MILITARY_DATA)

@router.message(FormStates.WAITING_MILITARY_CHOICE, F.text == "Перейти к следующему шагу")
async def go_next_military(message: Message, state: FSMContext):
    await ask_for_education(message, state)

@router.message(FormStates.WAITING_MILITARY_CHOICE)
async def unknown_military_choice(message: Message):
    await message.answer("Кнопки: «Добавить опыт службы» или «Перейти к следующему шагу».")

# ---------------------------
# Образование
# ---------------------------
async def ask_for_education(message: Message, state: FSMContext):
    await message.answer(
        "Пожалуйста, укажите данные об образовании (или нажмите «Пропустить»).\n\n"
        "Формат (4 строки):\n"
        "1) Наименование учебного учреждения\n"
        "2) Год начала (пробел) Год конца учёбы\n"
        "3) Вид образования (высшее, среднее, ...)\n"
        "4) Специальность\n",
        reply_markup=ReplyKeyboardMarkup(
            keyboard=[[KeyboardButton(text="Пропустить")]],
            resize_keyboard=True
        )
    )
    await state.set_state(FormStates.WAITING_EDUCATION_DATA)

@router.message(FormStates.WAITING_EDUCATION_DATA, F.text == "Пропустить")
async def skip_education(message: Message, state: FSMContext):
    await go_next_from_education(message, state)

@router.message(FormStates.WAITING_EDUCATION_DATA)
async def receive_education(message: Message, state: FSMContext):
    lines = message.text.split("\n")
    if len(lines) < 4:
        await message.answer("Нужно 4 строки!")
        return
    data_ = await state.get_data()
    edu_list = data_.get("education", [])
    edu_list.append({
        "institution": lines[0].strip(),
        "period": lines[1].strip(),
        "type": lines[2].strip(),
        "specialty": lines[3].strip()
    })
    await state.update_data({"education": edu_list})

    await message.answer(
        "Образование добавлено. «Добавить образование» или «Перейти к следующему шагу»?",
        reply_markup=edu_or_next_kb
    )
    await state.set_state(FormStates.WAITING_EDUCATION_CHOICE)

@router.message(FormStates.WAITING_EDUCATION_CHOICE, F.text == "Добавить образование")
async def add_more_education(message: Message, state: FSMContext):
    await message.answer(
        "Введите ещё 4 строки или «Пропустить».",
        reply_markup=ReplyKeyboardMarkup(
            keyboard=[[KeyboardButton(text="Пропустить")]],
            resize_keyboard=True
        )
    )
    await state.set_state(FormStates.WAITING_EDUCATION_DATA)

@router.message(FormStates.WAITING_EDUCATION_CHOICE, F.text == "Перейти к следующему шагу")
async def go_next_from_education(message: Message, state: FSMContext):
    # Дополнительные данные
    await message.answer(
        "Пожалуйста, укажите дополнительные данные (например, личные характеристики, навыки), "
        "или нажмите «Пропустить».",
        reply_markup=ReplyKeyboardMarkup(
            keyboard=[[KeyboardButton(text="Пропустить")]],
            resize_keyboard=True
        )
    )
    await state.set_state(FormStates.WAITING_ADDITIONAL_DATA)

@router.message(FormStates.WAITING_EDUCATION_CHOICE)
async def unknown_education_choice(message: Message):
    await message.answer("Кнопки: «Добавить образование» или «Перейти к следующему шагу».")

# ---------------------------
# Дополнительные данные
# ---------------------------
@router.message(FormStates.WAITING_ADDITIONAL_DATA, F.text == "Пропустить")
async def skip_additional(message: Message, state: FSMContext):
    await state.update_data({"additional_info": "Пропущено"})
    await message.answer(
        "Вы можете «Завершить» (создать PDF) или «Добавить блок доп. информации».",
        reply_markup=finish_or_add_block_kb
    )
    await state.set_state(FormStates.WAITING_FINISH_OR_ADD_BLOCK)

@router.message(FormStates.WAITING_ADDITIONAL_DATA)
async def receive_additional(message: Message, state: FSMContext):
    await state.update_data({"additional_info": message.text})
    await message.answer(
        "Вы можете «Завершить» (создать PDF) или «Добавить блок доп. информации».",
        reply_markup=finish_or_add_block_kb
    )
    await state.set_state(FormStates.WAITING_FINISH_OR_ADD_BLOCK)

@router.message(FormStates.WAITING_FINISH_OR_ADD_BLOCK, F.text == "Завершить")
async def finish_document(message: Message, state: FSMContext):
    """
    Генерируем PDF со всеми полями.
    """
    await generate_and_send_pdf(message, state)
    await state.set_state(FormStates.PDF_GENERATED)

@router.message(FormStates.WAITING_FINISH_OR_ADD_BLOCK, F.text == "Добавить блок доп. информации")
async def add_new_block_demo(message: Message):
    await message.answer("Здесь можно реализовать логику для новых полей (демо).")

@router.message(FormStates.WAITING_FINISH_OR_ADD_BLOCK)
async def unknown_finish_or_add_block(message: Message):
    await message.answer("Кнопки: «Завершить» или «Добавить блок доп. информации».")

# ---------------------------
# После генерации PDF
# ---------------------------
@router.message(FormStates.PDF_GENERATED, F.text == "Внести исправления")
async def edit_document(message: Message, state: FSMContext):
    await message.answer(
        "Что хотите исправить?",
        reply_markup=edit_menu_kb
    )
    await state.set_state(FormStates.WAITING_EDIT)

@router.message(FormStates.PDF_GENERATED, F.text == "Завершить")
async def final_send_document(message: Message, state: FSMContext):
    await message.answer("Документ сформирован окончательно. Завершаем.", reply_markup=ReplyKeyboardRemove())
    await state.clear()

@router.message(FormStates.PDF_GENERATED)
async def unknown_after_generation(message: Message):
    await message.answer("«Внести исправления» или «Завершить».")

@router.message(FormStates.WAITING_EDIT)
async def do_edit_stub(message: Message, state: FSMContext):
    """
    Выбираем, что редактировать. Демонстрационно показываем пример:
    """
    txt = message.text
    if txt == "Фотография 3x4":
        await message.answer("Пришлите новое фото 3×4.")
        await state.set_state(FormStates.WAITING_PHOTO_34)
    elif txt == "Фотография в полный рост":
        await message.answer("Пришлите новое фото в полный рост.")
        await state.set_state(FormStates.WAITING_PHOTO_FULL)
    elif txt == "Общая информация":
        await add_data_start(message, state)
    elif txt == "Опыт работы":
        await ask_for_work(message, state)
    elif txt == "Военная служба":
        await go_next_work(message, state)  # Переход к военной службе
    elif txt == "Образование":
        await ask_for_education(message, state)
    elif txt == "Дополнительная информация":
        await message.answer(
            "Дополнительные данные (навыки, характеристики) или «Пропустить».",
            reply_markup=ReplyKeyboardMarkup(
                keyboard=[[KeyboardButton(text="Пропустить")]],
                resize_keyboard=True
            )
        )
        await state.set_state(FormStates.WAITING_ADDITIONAL_DATA)
    else:
        await message.answer("Неизвестная команда. Выберите из списка.")

# ---------------------------
# Генерация PDF
# ---------------------------
async def generate_and_send_pdf(message: Message, state: FSMContext):
    data = await state.get_data()
    pdf_buffer = await generate_pdf(data)
    pdf_buffer.seek(0)
    pdf_bytes = pdf_buffer.read()

    await message.answer_document(
        document=BufferedInputFile(pdf_bytes, filename="Anketa.pdf"),
        caption="Готовый документ (PDF)."
    )
    await message.answer(
        "Хотите внести исправления или «Завершить»?",
        reply_markup=after_generation_kb
    )

async def generate_pdf(data: dict):
    """
    Формируем PDF в требуемом формате:
    - Фото 3×4 сверху,
    - Фото в полный рост,
    - Далее поля (общая инфа, опыт работы, военная служба, образование, доп. инфа).
    """
    buffer = BytesIO()

    # Создаём документ ReportLab
    doc = SimpleDocTemplate(
        buffer, pagesize=A4,
        leftMargin=2*cm, rightMargin=2*cm,
        topMargin=2*cm, bottomMargin=2*cm
    )

    styles = getSampleStyleSheet()
    style_normal = styles['Normal']
    style_normal.fontName = 'Montserrat'
    style_normal.fontSize = 10

    style_title = styles['Title']
    style_title.fontName = 'Montserrat'
    style_title.fontSize = 16

    style_heading = ParagraphStyle(
        'Heading',
        parent=style_normal,
        fontName='Montserrat',
        fontSize=12,
        spaceBefore=8,
        spaceAfter=4
    )

    elements = []

    # 1) Фотографии
    photo_3x4_path = data.get("photo_3x4")
    if photo_3x4_path and os.path.isfile(photo_3x4_path):
        img_34 = Image(photo_3x4_path, width=3*cm, height=4*cm)
    else:
        img_34 = Paragraph("<i>[Фото 3×4 не указано]</i>", style_normal)

    photo_full_path = data.get("photo_full")
    if photo_full_path and os.path.isfile(photo_full_path):
        img_full = Image(photo_full_path, width=4*cm, height=6*cm)
    else:
        img_full = Paragraph("<i>[Фото в полный рост не указано]</i>", style_normal)

    # Заголовок
    elements.append(Paragraph("Анкета сотрудника", style_title))
    elements.append(Spacer(1, 0.7*cm))

    # Блок с фото
    elements.append(Paragraph("Фото 3×4:", style_heading))
    elements.append(img_34)
    elements.append(Spacer(1, 0.5*cm))

    elements.append(Paragraph("Фото в полный рост:", style_heading))
    elements.append(img_full)
    elements.append(Spacer(1, 0.7*cm))

    # 2) Общая информация
    basic_info = data.get("basic_info", {})
    birth_date = basic_info.get("birth_date", "")
    registration = basic_info.get("registration", "")
    residence = basic_info.get("residence", "")
    height = basic_info.get("height", "")
    weight = basic_info.get("weight", "")
    marital = basic_info.get("marital", "")

    elements.append(Paragraph("Основная информация:", style_heading))
    table_basic = [
        ["Дата рождения:", birth_date],
        ["Место регистрации:", registration],
        ["Место проживания:", residence],
        ["Рост, вес:", f"{height} / {weight}"],
        ["Семейное положение:", marital],
    ]
    t_basic = Table(table_basic, colWidths=[5*cm, 9*cm])
    t_basic.setStyle(TableStyle([
        ('FONT', (0,0), (-1,-1), 'Montserrat', 10),
        ('VALIGN',(0,0),(-1,-1),'TOP'),
        ('BOTTOMPADDING', (0,0), (-1,-1), 4),
    ]))
    elements.append(t_basic)
    elements.append(Spacer(1, 0.7*cm))

    # 3) Опыт работы
    work_list = data.get("work_experience", [])
    elements.append(Paragraph("Опыт работы:", style_heading))
    if not work_list:
        elements.append(Paragraph("<i>Не указано</i>", style_normal))
    else:
        for i, w in enumerate(work_list, start=1):
            # Можем вывести кусочками
            elements.append(Paragraph(f"{i}) {w['employer']} ({w['city']})", style_normal))
            elements.append(Paragraph(f"Период: {w['period']}, Должность: {w['position']}", style_normal))
            elements.append(Paragraph(f"Обязанности: {w['duties']}", style_normal))
            elements.append(Spacer(1, 0.3*cm))

    elements.append(Spacer(1, 0.7*cm))

    # 4) Военная служба
    mil = data.get("military_service")
    elements.append(Paragraph("Военная служба:", style_heading))
    if mil:
        elements.append(Paragraph(f"Подразделение: {mil['subdivision']}", style_normal))
        elements.append(Paragraph(f"Срок службы: {mil['period']}", style_normal))
        elements.append(Paragraph(f"Звание: {mil['rank']}", style_normal))
        elements.append(Paragraph(f"Примечания: {mil['notes']}", style_normal))
    else:
        elements.append(Paragraph("<i>Не указана</i>", style_normal))

    elements.append(Spacer(1, 0.7*cm))

    # 5) Образование
    edu_list = data.get("education", [])
    elements.append(Paragraph("Образование:", style_heading))
    if not edu_list:
        elements.append(Paragraph("<i>Не указано</i>", style_normal))
    else:
        for i, e in enumerate(edu_list, start=1):
            elements.append(Paragraph(f"{i}) {e['institution']} ({e['period']})", style_normal))
            elements.append(Paragraph(f"Вид: {e['type']}, Специальность: {e['specialty']}", style_normal))
            elements.append(Spacer(1, 0.3*cm))

    elements.append(Spacer(1, 0.7*cm))

    # 6) Доп. данные
    add_info = data.get("additional_info", "")
    elements.append(Paragraph("Дополнительная информация:", style_heading))
    if add_info and add_info != "Пропущено":
        elements.append(Paragraph(add_info, style_normal))
    else:
        elements.append(Paragraph("<i>Не указана</i>", style_normal))

    doc.build(elements)
    buffer.seek(0)
    return buffer

dp.include_router(router)

async def main():
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())