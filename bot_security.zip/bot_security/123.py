import os
import asyncio
from io import BytesIO

from dotenv import load_dotenv
from aiogram import Bot, Dispatcher, Router, F
from aiogram.types import (
    Message, PhotoSize,
    ReplyKeyboardMarkup, KeyboardButton,
    ReplyKeyboardRemove, BufferedInputFile
)
from aiogram.filters import CommandStart
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import StatesGroup, State
from aiogram.fsm.storage.memory import MemoryStorage

# REPORTLAB + Montserrat
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import cm
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle

# 1) Загружаем токен из .env
load_dotenv()
BOT_TOKEN = os.getenv("BOT_TOKEN")

# Настраиваем бота
bot = Bot(token=BOT_TOKEN)
dp = Dispatcher(storage=MemoryStorage())
router = Router()

# 2) Регистрируем шрифт Montserrat (должен лежать в папке fonts/Montserrat-Regular.ttf)
pdfmetrics.registerFont(TTFont('Montserrat', 'fonts/Montserrat-Regular.ttf'))

# Создадим папку для фото (на всякий случай), если её нет
os.makedirs("photos", exist_ok=True)

# ---------------------------
# Клавиатуры
# ---------------------------

# Главное меню языка
choose_language_kb = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="Создать анкету на русском")],
        [KeyboardButton(text="Create form in English")],
    ],
    resize_keyboard=True
)

# Кнопка "Назад" (и "Back") вместе
back_to_lang_kb = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="Назад"), KeyboardButton(text="Back")]
    ],
    resize_keyboard=True
)

# Меню "Добавить / Завершить" на русском
add_or_finish_kb_ru = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="Добавить данные")],
        [KeyboardButton(text="Завершить создание документа")],
    ],
    resize_keyboard=True
)

# Меню "Add / Finish" на английском
add_or_finish_kb_en = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="Add data")],
        [KeyboardButton(text="Finish document")],
    ],
    resize_keyboard=True
)

# "Добавить опыт работы" / "Перейти к следующему шагу" (рус)
work_or_next_kb_ru = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="Добавить опыт работы")],
        [KeyboardButton(text="Перейти к следующему шагу")],
    ],
    resize_keyboard=True
)

work_or_next_kb_en = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="Add work experience")],
        [KeyboardButton(text="Go to next step")],
    ],
    resize_keyboard=True
)

# Военная служба
service_or_next_kb_ru = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="Добавить опыт службы")],
        [KeyboardButton(text="Перейти к следующему шагу")],
    ],
    resize_keyboard=True
)

service_or_next_kb_en = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="Add military service")],
        [KeyboardButton(text="Go to next step")],
    ],
    resize_keyboard=True
)

# Образование
edu_or_next_kb_ru = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="Добавить образование")],
        [KeyboardButton(text="Перейти к следующему шагу")],
    ],
    resize_keyboard=True
)

edu_or_next_kb_en = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="Add education")],
        [KeyboardButton(text="Go to next step")],
    ],
    resize_keyboard=True
)

# "Добавить блок доп. инф." / "Завершить"
finish_or_add_block_kb_ru = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="Добавить блок доп. информации")],
        [KeyboardButton(text="Завершить")],
    ],
    resize_keyboard=True
)
finish_or_add_block_kb_en = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="Add extra info block")],
        [KeyboardButton(text="Finish")],
    ],
    resize_keyboard=True
)

# После генерации: "Внести исправления" / "Завершить"
after_generation_kb_ru = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="Внести исправления")],
        [KeyboardButton(text="Завершить")],
    ],
    resize_keyboard=True
)
after_generation_kb_en = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="Edit data")],
        [KeyboardButton(text="Finish")],
    ],
    resize_keyboard=True
)

# Меню "Внести исправления": список кнопок редактирования
edit_menu_kb_ru = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="Фотография 3x4"), KeyboardButton(text="Фотография в полный рост")],
        [KeyboardButton(text="Общая информация"), KeyboardButton(text="Опыт работы")],
        [KeyboardButton(text="Военная служба"), KeyboardButton(text="Образование")],
        [KeyboardButton(text="Дополнительная информация")],
    ],
    resize_keyboard=True
)
edit_menu_kb_en = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="Photo 3x4"), KeyboardButton(text="Full height photo")],
        [KeyboardButton(text="Basic info"), KeyboardButton(text="Work experience")],
        [KeyboardButton(text="Military service"), KeyboardButton(text="Education")],
        [KeyboardButton(text="Additional info")],
    ],
    resize_keyboard=True
)

# ---------------------------
# Состояния
# ---------------------------
class FormStates(StatesGroup):
    CHOOSE_LANG = State()
    WAITING_PHOTO_34 = State()
    WAITING_PHOTO_FULL = State()
    WAITING_ADD_OR_FINISH = State()

    WAITING_BASIC_INFO = State()
    WAITING_WORK = State()
    WAITING_WORK_CHOICE = State()

    WAITING_MILITARY_DATA = State()
    WAITING_MILITARY_CHOICE = State()

    WAITING_EDUCATION_DATA = State()
    WAITING_EDUCATION_CHOICE = State()

    WAITING_ADDITIONAL_DATA = State()
    WAITING_FINISH_OR_ADD_BLOCK = State()

    PDF_GENERATED = State()
    WAITING_EDIT = State()

# ---------------------------
# Утилита получения языка
# ---------------------------
async def get_lang(state: FSMContext) -> str:
    data = await state.get_data()
    return data.get("lang", "ru")

# 4) Логика
# ---------------------------
@router.message(CommandStart())
async def cmd_start(message: Message, state: FSMContext):
    """
    Показываем выбор языка (рус/англ). Очищаем данные.
    """
    await state.clear()
    await message.answer(
        "Привет! Это бот для создания анкет.\nВыберите язык анкеты:",
        reply_markup=choose_language_kb
    )
    await state.set_state(FormStates.CHOOSE_LANG)


@router.message(FormStates.CHOOSE_LANG, F.text == "Создать анкету на русском")
async def form_russian(message: Message, state: FSMContext):
    """
    Русский сценарий
    """
    # Сохраняем, что выбрали русский
    await state.update_data({
        "lang": "ru",
        "photo_3x4": None,
        "photo_full": None,
        "basic_info": {},
        "work_experience": [],
        "military_service": None,
        "education": [],
        "additional_info": None
    })

    # Просим фото 3x4
    await message.answer(
        "Вы выбрали анкету на русском.\n"
        "Пожалуйста, отправьте фотографию (как на паспорт) — 3/4.",
        reply_markup=back_to_lang_kb  # вместо кнопок "рус/англ" — даём "Назад"
    )
    await state.set_state(FormStates.WAITING_PHOTO_34)


@router.message(FormStates.CHOOSE_LANG, F.text == "Создать анкету на английском")
async def form_english(message: Message, state: FSMContext):
    """
    Английский сценарий (демо-коротко)
    """
    await state.update_data({
        "lang": "en",
        "photo_3x4": None,
        "photo_full": None,
        "basic_info": {},
        "work_experience": [],
        "military_service": None,
        "education": [],
        "additional_info": None
    })
    await message.answer(
        "You have chosen to fill the form in English.\n"
        "Please send a 3/4 photo (like on a passport).",
        reply_markup=back_to_lang_kb
    )
    await state.set_state(FormStates.WAITING_PHOTO_34)


@router.message(FormStates.CHOOSE_LANG, F.text == "Назад")
async def choose_lang_back(message: Message, state: FSMContext):
    # Если вдруг нажали "Назад" - но мы ещё в выборе языка
    await cmd_start(message, state)


@router.message(FormStates.WAITING_PHOTO_34, F.text == "Назад")
async def photo34_back(message: Message, state: FSMContext):
    # Вернуться к выбору языка
    await cmd_start(message, state)


@router.message(FormStates.WAITING_PHOTO_34, F.photo)
async def receive_photo_34(message: Message, state: FSMContext):
    # Сохраняем file_id
    file_id = message.photo[-1].file_id
    await state.update_data({"photo_3x4": file_id})

    await message.answer(
        "Фото 3/4 получено!\nТеперь отправьте фотографию сотрудника в полный рост.",
        reply_markup=back_to_lang_kb
    )
    await state.set_state(FormStates.WAITING_PHOTO_FULL)


@router.message(FormStates.WAITING_PHOTO_FULL, F.photo)
async def receive_photo_full(message: Message, state: FSMContext):
    file_id = message.photo[-1].file_id
    await state.update_data({"photo_full": file_id})

    # Предлагаем добавить данные или завершить
    await message.answer(
        "Фото в полный рост получено.\nТеперь вы можете добавить информацию или сразу завершить документ.",
        reply_markup=add_or_finish_kb_ru
    )
    await state.set_state(FormStates.WAITING_ADD_OR_FINISH)


@router.message(FormStates.WAITING_PHOTO_FULL, F.text == "Назад")
async def photo_full_back(message: Message, state: FSMContext):
    # Вернуться к фото 3x4
    await form_russian(message, state)  # или form_english, если lang=en (нужно доп. логику)


@router.message(FormStates.WAITING_ADD_OR_FINISH, F.text == "Добавить данные")
async def add_data_start(message: Message, state: FSMContext):
    # Запрашиваем основную инфу
    await message.answer(
        "Пожалуйста, укажите дату и место рождения, место регистрации, рост, вес, семейное положение.\n\n"
        "Пример (каждое поле с новой строки!):\n"
        "01.01.1990\n"
        "Санкт-Петербург\n"
        "Москва (текущее место проживания)\n"
        "190\n"
        "90\n"
        "Женат\n\n"
        "Или нажмите «Пропустить».",
        # Убираем кнопки "Добавить" - пользователь просто вводит
        reply_markup=ReplyKeyboardMarkup(
            keyboard=[
                [KeyboardButton(text="Пропустить")],
            ],
            resize_keyboard=True
        )
    )
    await state.set_state(FormStates.WAITING_BASIC_INFO)


@router.message(FormStates.WAITING_ADD_OR_FINISH, F.text == "Завершить создание документа")
async def finish_early(message: Message, state: FSMContext):
    await generate_and_send_pdf(message, state)
    await state.set_state(FormStates.PDF_GENERATED)


# Если нажали что-то иное
@router.message(FormStates.WAITING_ADD_OR_FINISH)
async def unknown_add_or_finish(message: Message):
    await message.answer("Пожалуйста, используйте кнопки: «Добавить данные» или «Завершить создание документа».")


@router.message(FormStates.WAITING_BASIC_INFO, F.text == "Пропустить")
async def skip_basic_info(message: Message, state: FSMContext):
    await state.update_data({"basic_info": {
        "birth_date": "Пропущено",
        "registration": "Пропущено",
        "residence": "Пропущено",
        "height": "Пропущено",
        "weight": "Пропущено",
        "marital": "Пропущено"
    }})
    await ask_for_work(message, state)


@router.message(FormStates.WAITING_BASIC_INFO)
async def receive_basic_info(message: Message, state: FSMContext):
    lines = message.text.split("\n")
    if len(lines) < 6:
        await message.answer("Нужно 6 строк!")
        return
    # Сохраняем
    bdict = {
        "birth_date": lines[0].strip(),
        "registration": lines[1].strip(),
        "residence": lines[2].strip(),
        "height": lines[3].strip(),
        "weight": lines[4].strip(),
        "marital": lines[5].strip()
    }
    await state.update_data({"basic_info": bdict})
    await ask_for_work(message, state)


async def ask_for_work(message: Message, state: FSMContext):
    await message.answer(
        "Пожалуйста, укажите данные об опыте работы в следующем формате (5 строк, обязательно перенос строк!):\n\n"
        "1) Наименование работодателя\n"
        "2) Город места работы\n"
        "3) Период (например: 2010 2015)\n"
        "4) Должность\n"
        "5) Обязанности\n\n"
        "Или нажмите «Пропустить» чтобы перейти к следующему шагу.",
        reply_markup=ReplyKeyboardMarkup(
            keyboard=[
                [KeyboardButton(text="Пропустить")],
            ],
            resize_keyboard=True
        )
    )
    await state.set_state(FormStates.WAITING_WORK)


@router.message(FormStates.WAITING_WORK, F.text == "Пропустить")
async def skip_work(message: Message, state: FSMContext):
    await go_next_work(message, state)


@router.message(FormStates.WAITING_WORK)
async def receive_work(message: Message, state: FSMContext):
    lines = message.text.split("\n")
    if len(lines) < 5:
        await message.answer("Нужно 5 строк!")
        return
    data_ = await state.get_data()
    wlist = data_.get("work_experience", [])
    wdict = {
        "employer": lines[0].strip(),
        "city": lines[1].strip(),
        "period": lines[2].strip(),
        "position": lines[3].strip(),
        "duties": lines[4].strip()
    }
    wlist.append(wdict)
    await state.update_data({"work_experience": wlist})

    await message.answer(
        "Опыт работы добавлен. «Добавить опыт работы» или «Перейти к следующему шагу»?",
        reply_markup=work_or_next_kb_ru
    )
    await state.set_state(FormStates.WAITING_WORK_CHOICE)


@router.message(FormStates.WAITING_WORK_CHOICE, F.text == "Добавить опыт работы")
async def add_more_work_exp(message: Message, state: FSMContext):
    await message.answer(
        "Введите ещё 5 строк или «Пропустить»",
        reply_markup=ReplyKeyboardMarkup(
            keyboard=[
                [KeyboardButton(text="Пропустить")],
            ],
            resize_keyboard=True
        )
    )
    await state.set_state(FormStates.WAITING_WORK)


@router.message(FormStates.WAITING_WORK_CHOICE, F.text == "Перейти к следующему шагу")
async def go_next_work(message: Message, state: FSMContext):
    # Военная служба
    await message.answer(
        "Пожалуйста, укажите данные о военной службе или нажмите «Пропустить».\n\n"
        "Формат (4 строки):\n"
        "1) Наименование подразделения\n"
        "2) Год начала (пробел) Год конца службы\n"
        "3) Звание\n"
        "4) Обязанности/Примечания\n",
        reply_markup=ReplyKeyboardMarkup(
            keyboard=[
                [KeyboardButton(text="Пропустить")],
            ],
            resize_keyboard=True
        )
    )
    await state.set_state(FormStates.WAITING_MILITARY_DATA)


@router.message(FormStates.WAITING_WORK_CHOICE)
async def unknown_work_choice(message: Message):
    await message.answer("Кнопки: «Добавить опыт работы» или «Перейти к следующему шагу».")


@router.message(FormStates.WAITING_MILITARY_DATA, F.text == "Пропустить")
async def skip_military(message: Message, state: FSMContext):
    await state.update_data({"military_service": None})
    await ask_for_education(message, state)


@router.message(FormStates.WAITING_MILITARY_DATA)
async def receive_military(message: Message, state: FSMContext):
    lines = message.text.split("\n")
    if len(lines) < 4:
        await message.answer("Нужно 4 строки!")
        return
    ms_dict = {
        "subdivision": lines[0].strip(),
        "period": lines[1].strip(),
        "rank": lines[2].strip(),
        "notes": lines[3].strip()
    }
    await state.update_data({"military_service": ms_dict})
    await message.answer(
        "Военная служба добавлена. «Добавить опыт службы» или «Перейти к следующему шагу»?",
        reply_markup=service_or_next_kb_ru
    )
    await state.set_state(FormStates.WAITING_MILITARY_CHOICE)


@router.message(FormStates.WAITING_MILITARY_CHOICE, F.text == "Добавить опыт службы")
async def add_more_military(message: Message, state: FSMContext):
    await message.answer(
        "Введите ещё 4 строки или «Пропустить»",
        reply_markup=ReplyKeyboardMarkup(
            keyboard=[
                [KeyboardButton(text="Пропустить")],
            ],
            resize_keyboard=True
        )
    )
    await state.set_state(FormStates.WAITING_MILITARY_DATA)


@router.message(FormStates.WAITING_MILITARY_CHOICE, F.text == "Перейти к следующему шагу")
async def go_next_military(message: Message, state: FSMContext):
    await ask_for_education(message, state)


@router.message(FormStates.WAITING_MILITARY_CHOICE)
async def unknown_military_choice(message: Message):
    await message.answer("Кнопки: «Добавить опыт службы» или «Перейти к следующему шагу».")


async def ask_for_education(message: Message, state: FSMContext):
    await message.answer(
        "Пожалуйста, укажите данные об образовании (или нажмите «Пропустить»).\n\n"
        "Формат (4 строки):\n"
        "1) Наименование учебного учреждения\n"
        "2) Год начала (пробел) Год конца учёбы\n"
        "3) Вид образования (высшее, среднее, ...)\n"
        "4) Специальность\n",
        reply_markup=ReplyKeyboardMarkup(
            keyboard=[
                [KeyboardButton(text="Пропустить")],
            ],
            resize_keyboard=True
        )
    )
    await state.set_state(FormStates.WAITING_EDUCATION_DATA)


@router.message(FormStates.WAITING_EDUCATION_DATA, F.text == "Пропустить")
async def skip_education(message: Message, state: FSMContext):
    await go_next_education(message, state)


@router.message(FormStates.WAITING_EDUCATION_DATA)
async def receive_education(message: Message, state: FSMContext):
    lines = message.text.split("\n")
    if len(lines) < 4:
        await message.answer("Нужно 4 строки!")
        return
    data_ = await state.get_data()
    edu_list = data_.get("education", [])
    e_dict = {
        "institution": lines[0].strip(),
        "period": lines[1].strip(),
        "type": lines[2].strip(),
        "specialty": lines[3].strip()
    }
    edu_list.append(e_dict)
    await state.update_data({"education": edu_list})
    await message.answer(
        "Образование добавлено. «Добавить образование» или «Перейти к следующему шагу»?",
        reply_markup=edu_or_next_kb_ru
    )
    await state.set_state(FormStates.WAITING_EDUCATION_CHOICE)


@router.message(FormStates.WAITING_EDUCATION_CHOICE, F.text == "Добавить образование")
async def add_more_education(message: Message, state: FSMContext):
    await message.answer(
        "Введите ещё 4 строки или «Пропустить».",
        reply_markup=ReplyKeyboardMarkup(
            keyboard=[
                [KeyboardButton(text="Пропустить")],
            ],
            resize_keyboard=True
        )
    )
    await state.set_state(FormStates.WAITING_EDUCATION_DATA)


@router.message(FormStates.WAITING_EDUCATION_CHOICE, F.text == "Перейти к следующему шагу")
async def go_next_education(message: Message, state: FSMContext):
    # Дополнительные данные
    await message.answer(
        "Дополнительные данные (навыки, характеристики) или «Пропустить».",
        reply_markup=ReplyKeyboardMarkup(
            keyboard=[
                [KeyboardButton(text="Пропустить")],
            ],
            resize_keyboard=True
        )
    )
    await state.set_state(FormStates.WAITING_ADDITIONAL_DATA)


@router.message(FormStates.WAITING_EDUCATION_CHOICE)
async def unknown_education_choice(message: Message):
    await message.answer("Кнопки: «Добавить образование» или «Перейти к следующему шагу».")


@router.message(FormStates.WAITING_ADDITIONAL_DATA, F.text == "Пропустить")
async def skip_additional(message: Message, state: FSMContext):
    await state.update_data({"additional_info": "Пропущено"})
    await message.answer(
        "Можете «Завершить» (создать PDF) или «Добавить блок доп. информации».",
        reply_markup=finish_or_add_block_kb
    )
    await state.set_state(FormStates.WAITING_FINISH_OR_ADD_BLOCK)


@router.message(FormStates.WAITING_ADDITIONAL_DATA)
async def receive_additional(message: Message, state: FSMContext):
    await state.update_data({"additional_info": message.text})
    await message.answer(
        "Можете «Завершить» (создать PDF) или «Добавить блок доп. информации».",
        reply_markup=finish_or_add_block_kb_ru
    )
    await state.set_state(FormStates.WAITING_FINISH_OR_ADD_BLOCK)


@router.message(FormStates.WAITING_FINISH_OR_ADD_BLOCK, F.text == "Завершить")
async def finish_document(message: Message, state: FSMContext):
    await generate_and_send_pdf(message, state)
    await state.set_state(FormStates.PDF_GENERATED)


@router.message(FormStates.WAITING_FINISH_OR_ADD_BLOCK, F.text == "Добавить блок доп. информации")
async def add_extra_block(message: Message, state: FSMContext):
    await message.answer("Демо: тут можно добавить новые поля или вернуться к шагам.")


@router.message(FormStates.WAITING_FINISH_OR_ADD_BLOCK)
async def unknown_finish_or_add_block(message: Message):
    await message.answer("Кнопки: «Завершить» или «Добавить блок доп. информации».")


# ---------------------------
# После генерации PDF
# ---------------------------
@router.message(FormStates.PDF_GENERATED, F.text == "Внести исправления")
async def edit_document(message: Message, state: FSMContext):
    await message.answer(
        "Что хотите исправить?",
        reply_markup=edit_menu_kb
    )
    await state.set_state(FormStates.WAITING_EDIT)


@router.message(FormStates.PDF_GENERATED, F.text == "Завершить")
async def finalize_doc(message: Message, state: FSMContext):
    await message.answer("Документ сформирован окончательно. Завершаем.", reply_markup=ReplyKeyboardRemove())
    await state.clear()


@router.message(FormStates.PDF_GENERATED)
async def unknown_after_pdf(message: Message):
    await message.answer("«Внести исправления» или «Завершить».")


@router.message(FormStates.WAITING_EDIT)
async def edit_which_block(message: Message, state: FSMContext):
    """
    Демо: по нажатию на одну из кнопок "Фотография 3x4" / "Военная служба" / ...
    возвращаемся к нужному состоянию.
    """
    txt = message.text

    if txt == "Фотография 3x4":
        await message.answer("Пришлите новое фото 3x4.")
        await state.set_state(FormStates.WAITING_PHOTO_34)
    elif txt == "Фотография в полный рост":
        await message.answer("Пришлите новое фото в полный рост.")
        await state.set_state(FormStates.WAITING_PHOTO_FULL)
    elif txt == "Общая информация":
        await add_data_start(message, state)
    elif txt == "Опыт работы":
        await ask_for_work(message, state)
    elif txt == "Военная служба":
        await go_next_work(message, state)  # Т.е. перейдём к военной службе
    elif txt == "Образование":
        await ask_for_education(message, state)
    elif txt == "Дополнительная информация":
        await message.answer(
            "Дополнительные данные (навыки, характеристики) или «Пропустить».",
            reply_markup=ReplyKeyboardMarkup(
                keyboard=[
                    [KeyboardButton(text="Пропустить")],
                ],
                resize_keyboard=True
            )
        )
        await state.set_state(FormStates.WAITING_ADDITIONAL_DATA)
    else:
        await message.answer("Неизвестный блок. Выберите из списка.")
        return

    # Как только блок до заполнится, снова сгенерируем PDF
    # (см. соответствующий хендлер).


# ---------------------------

# ---------------------------
# Пример функции generate_pdf
# ---------------------------
async def generate_pdf(data: dict):
    """
    Используем Montserrat, вставляем фото 3x4, фото полного роста,
    выводим поля. Делаем и русский, и английский вариант.
    """
    buffer = BytesIO()

    doc = SimpleDocTemplate(
        buffer, pagesize=A4,
        leftMargin=2*cm, rightMargin=2*cm,
        topMargin=2*cm, bottomMargin=2*cm
    )

    styles = getSampleStyleSheet()

    style_normal = styles['Normal']
    style_normal.fontName = 'Montserrat'
    style_normal.fontSize = 10

    style_title = styles['Title']
    style_title.fontName = 'Montserrat'
    style_title.fontSize = 16

    style_heading = ParagraphStyle(
        'Heading',
        parent=style_normal,
        fontName='Montserrat',
        fontSize=12,
        spaceBefore=10,
        spaceAfter=5
    )

    lang = data.get("lang","ru")

    elements = []

    photo_3x4_path = data.get("photo_3x4")
    if photo_3x4_path and os.path.isfile(photo_3x4_path):
        photo_3x4_img = Image(photo_3x4_path, width=3*cm, height=4*cm)
    else:
        photo_3x4_img = Paragraph("<i>No 3x4 photo</i>", style_normal)

    photo_full_path = data.get("photo_full")
    if photo_full_path and os.path.isfile(photo_full_path):
        photo_full_img = Image(photo_full_path, width=4*cm, height=6*cm)
    else:
        photo_full_img = Paragraph("<i>No full-height photo</i>", style_normal)

    if lang=="ru":
        elements.append(Paragraph("<b>Анкета</b>", style_title))
        elements.append(Spacer(1, 0.5*cm))

        elements.append(Paragraph("Фото 3×4:", style_heading))
        elements.append(photo_3x4_img)
        elements.append(Spacer(1, 0.5*cm))

        elements.append(Paragraph("Фото в полный рост:", style_heading))
        elements.append(photo_full_img)
        elements.append(Spacer(1, 1*cm))

        # Можно вывести поля "basic_info" и т.д. в таблицы
        # Ниже упрощённый пример
        binfo = data.get("basic_info", {})
        birth_date = binfo.get("birth_date","")
        registration = binfo.get("registration","")
        # ...

        elements.append(Paragraph("Основная информация:", style_heading))
        # ... и так далее
        # (Добавьте опыт работы, военная служба, образование, доп.инфо)

    else:
        elements.append(Paragraph("<b>Form</b>", style_title))
        elements.append(Spacer(1, 0.5*cm))

        elements.append(Paragraph("3×4 photo:", style_heading))
        elements.append(photo_3x4_img)
        elements.append(Spacer(1, 0.5*cm))

        elements.append(Paragraph("Full-height photo:", style_heading))
        elements.append(photo_full_img)
        elements.append(Spacer(1, 1*cm))

        # Similarly for "Basic info", "Work experience", etc.

    doc.build(elements)
    buffer.seek(0)
    return buffer

# ---------------------------
# Редактирование
# ---------------------------
@router.message(FormStates.PDF_GENERATED, F.text.in_(["Внести исправления", "Edit data"]))
async def edit_document(message: Message, state: FSMContext):
    lang = await get_lang(state)
    if lang=="ru":
        await message.answer("Что хотите исправить?", reply_markup=edit_menu_kb_ru)
    else:
        await message.answer("What do you want to edit?", reply_markup=edit_menu_kb_en)
    await state.set_state(FormStates.WAITING_EDIT)

@router.message(FormStates.PDF_GENERATED, F.text.in_(["Завершить", "Finish"]))
async def finalize_doc(message: Message, state: FSMContext):
    lang = await get_lang(state)
    if lang=="ru":
        text = "Документ сформирован окончательно. Завершаем."
    else:
        text = "Document is finalized. Done."

    await message.answer(text, reply_markup=ReplyKeyboardRemove())
    await state.clear()

@router.message(FormStates.PDF_GENERATED)
async def unknown_after_pdf(message: Message, state: FSMContext):
    lang = await get_lang(state)
    if lang=="ru":
        await message.answer("«Внести исправления» или «Завершить».")
    else:
        await message.answer("'Edit data' or 'Finish'.")

# ---------------------------
# Обработка конкретного выбора для редактирования
# ---------------------------
@router.message(FormStates.WAITING_EDIT)
async def edit_which_block(message: Message, state: FSMContext):
    txt = message.text
    lang = await get_lang(state)

    # Для демонстрации: если выбрали "Фотография 3x4" — перейдём к WAITING_PHOTO_34
    # и попросим новую фотку
    if txt in ["Фотография 3x4", "Photo 3x4"]:
        if lang=="ru":
            t = "Пришлите новое фото 3×4."
        else:
            t = "Please send new 3×4 photo."
        await message.answer(t, reply_markup=back_to_lang_kb)
        await state.set_state(FormStates.WAITING_PHOTO_34)

    elif txt in ["Фотография в полный рост", "Full height photo"]:
        if lang=="ru":
            t = "Пришлите новое фото в полный рост."
        else:
            t = "Send new full-height photo."
        await message.answer(t, reply_markup=back_to_lang_kb)
        await state.set_state(FormStates.WAITING_PHOTO_FULL)

    elif txt in ["Общая информация", "Basic info"]:
        if lang=="ru":
            # Перекинем снова в WAITING_BASIC_INFO
            t = ("Пожалуйста, укажите дату и место рождения, место регистрации, рост, вес, семейное положение.\n"
                 "Или «Пропустить».")
        else:
            t = ("Please enter birth date, registration place, residence, height, weight, marital.\n"
                 "Or 'Skip'.")
        # ...
        await message.answer(t)
        await state.set_state(FormStates.WAITING_BASIC_INFO)

    elif txt in ["Опыт работы", "Work experience"]:
        # Снова спрашиваем опыт работы
        # ...
        if lang=="ru":
            question = (
                "Пожалуйста, укажите данные об опыте работы (5 строк, обязательно перенос строк!):\n\n"
                "1) Наименование работодателя\n"
                "2) Город места работы\n"
                "3) Период (например: 2010 2015)\n"
                "4) Должность\n"
                "5) Обязанности\n\n"
                "Или нажмите «Пропустить»..."
            )
        else:
            question = (
                "Please provide work experience data (5 lines, must use line breaks):\n\n"
                "1) Employer\n"
                "2) City\n"
                "3) Period (e.g. 2010 2015)\n"
                "4) Position\n"
                "5) Duties\n\n"
                "Or press 'Skip'..."
            )
        await message.answer(question)
        await state.set_state(FormStates.WAITING_WORK)

    elif txt in ["Военная служба", "Military service"]:
        if lang=="ru":
            q = ("Пожалуйста, укажите данные о военной службе или нажмите «Пропустить».\n\n"
                 "Формат (4 строки):\n"
                 "1) Наименование подразделения\n"
                 "2) Год начала (пробел) Год конца службы\n"
                 "3) Звание\n"
                 "4) Обязанности/Примечания\n")
        else:
            q = ("Please enter military service data or press 'Skip'.\n\n"
                 "Format (4 lines):\n"
                 "1) Subdivision\n"
                 "2) Start year (space) end year\n"
                 "3) Rank\n"
                 "4) Duties/Notes\n")
        await message.answer(q)
        await state.set_state(FormStates.WAITING_MILITARY_DATA)

    elif txt in ["Образование", "Education"]:
        if lang=="ru":
            q = ("Пожалуйста, укажите данные об образовании (или нажмите «Пропустить»).\n\n"
                 "Формат (4 строки):\n"
                 "1) Наименование учебного учреждения\n"
                 "2) Год начала (пробел) Год конца учёбы\n"
                 "3) Вид образования (высшее, среднее, ...)\n"
                 "4) Специальность\n")
        else:
            q = ("Please enter education data or press 'Skip'.\n\n"
                 "Format (4 lines):\n"
                 "1) Institution name\n"
                 "2) Start year (space) end year\n"
                 "3) Education type\n"
                 "4) Specialty\n")
        await message.answer(q)
        await state.set_state(FormStates.WAITING_EDUCATION_DATA)

    elif txt in ["Дополнительная информация", "Additional info"]:
        if lang=="ru":
            q = "Дополнительные данные (навыки, характеристики) или «Пропустить»."
        else:
            q = "Additional info (skills, etc.) or 'Skip'."
        await message.answer(q)
        await state.set_state(FormStates.WAITING_ADDITIONAL_DATA)

    else:
        if lang=="ru":
            await message.answer("Неизвестная команда. Выберите из списка.")
        else:
            await message.answer("Unknown command. Choose from the list.")

# ---------------------------
# Запуск
# ---------------------------
dp.include_router(router)

async def main():
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())